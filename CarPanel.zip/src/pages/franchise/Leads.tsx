import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MessagesSquare } from "lucide-react";

const InquiryLeads = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">Inquiry & Leads</h1>
        <p className="text-muted-foreground mt-1">Manage customer inquiries and leads</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessagesSquare className="h-5 w-5" />
            Active Leads
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">Inquiry management interface coming soon</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default InquiryLeads;
