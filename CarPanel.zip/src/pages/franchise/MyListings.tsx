import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FileText } from "lucide-react";

const MyListings = () => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold">My Listings</h1>
        <p className="text-muted-foreground mt-1">View and manage your car listings</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5" />
            Your Listings
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-muted-foreground">My listings interface coming soon</p>
        </CardContent>
      </Card>
    </div>
  );
};

export default MyListings;
