// src/authapi/dealerApi.js
export const DEALER_BASE_URL = "https://seediest-brynlee-nondefensive.ngrok-free.dev/api/v1/dealer";

export const DEALER_API_ENDPOINTS = {
  
};