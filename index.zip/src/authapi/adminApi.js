

export const API_BASE_URL = "http://localhost:8002/api/v1/admin";

export const ADMIN_API_ENDPOINTS = {
  
};