// import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
// import { Car } from "lucide-react";

// const ListingVerification = () => {
//   return (
//     <div className="space-y-6">
//       <div>
//         <h1 className="text-3xl font-bold">Listing Verification</h1>
//         <p className="text-muted-foreground mt-1">Verify and approve car listings</p>
//       </div>

//       <Card>
//         <CardHeader>
//           <CardTitle className="flex items-center gap-2">
//             <Car className="h-5 w-5" />
//             Pending Verifications
//           </CardTitle>
//         </CardHeader>
//         <CardContent>
//           <p className="text-muted-foreground">Listing verification interface coming soon</p>
//         </CardContent>
//       </Card>
//     </div>
//   );
// };

// export default ListingVerification;


// import { useState, useEffect } from "react";
// import axios from "axios";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
// import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
// import {
//   Dialog,
//   DialogContent,
//   DialogHeader,
//   DialogTitle,
//   DialogDescription,
//   DialogFooter,
// } from "@/components/ui/dialog";
// import { Textarea } from "@/components/ui/textarea";
// import { Skeleton } from "@/components/ui/skeleton";
// import { useToast } from "@/hooks/use-toast";
// import {
//   Car,
//   MapPin,
//   Fuel,
//   Calendar,
//   User,
//   Phone,
//   FileText,
//   Video,
//   X,
//   Eye,
//   XCircle,
//   ImageIcon,
//   AlertCircle,
//   RefreshCw,
//   Gauge,
//   Users,
//   Palette,
//   Hash,
//   IndianRupee,
//   Clock,
//   CheckCircle2,
//   Ban,
//   ShoppingCart,
//   Loader2,
// } from "lucide-react";

// const API_BASE = "https://your-api-base.com";

// interface CarListing {
//   _id: string;
//   sellerName: string;
//   sellerMobile: string;
//   city: string;
//   pincode: string;
//   make: string;
//   model: string;
//   variant: string;
//   year: number;
//   kmDriven: number;
//   fuelType: string;
//   transmission: string;
//   registrationCity: string;
//   registrationNumber: string;
//   noOfOwners: number;
//   color: string;
//   expectedPrice: number;
//   negotiable: boolean;
//   description: string;
//   images: string[];
//   documents: string[];
//   inspectionVideo?: string;
//   sellerType: "franchise" | "individual";
//   listingType: "self" | "assisted";
//   status: "pending_verification" | "approved" | "live" | "sold" | "rejected";
//   qualityRating?: number;
//   createdAt: string;
// }

// type TabStatus = "pending_verification" | "approved" | "live" | "sold" | "rejected";

// const statusConfig: Record<TabStatus, { label: string; color: string; icon: React.ReactNode }> = {
//   pending_verification: { label: "Pending", color: "bg-warning/20 text-warning border-warning/30", icon: <Clock className="w-3 h-3" /> },
//   approved: { label: "Approved", color: "bg-primary/20 text-primary border-primary/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   live: { label: "Live", color: "bg-success/20 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   sold: { label: "Sold", color: "bg-success/20 text-success border-success/30", icon: <ShoppingCart className="w-3 h-3" /> },
//   rejected: { label: "Rejected", color: "bg-destructive/20 text-destructive border-destructive/30", icon: <Ban className="w-3 h-3" /> },
// };

// const ListingVerification = () => {
//   const { toast } = useToast();
//   const [activeTab, setActiveTab] = useState<TabStatus>("pending_verification");
//   const [listings, setListings] = useState<CarListing[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);

//   const [selectedCar, setSelectedCar] = useState<CarListing | null>(null);
//   const [detailsOpen, setDetailsOpen] = useState(false);

//   const [rejectCar, setRejectCar] = useState<CarListing | null>(null);
//   const [rejectOpen, setRejectOpen] = useState(false);
//   const [rejectReason, setRejectReason] = useState("");
//   const [rejecting, setRejecting] = useState(false);

//   const fetchListings = async (status: TabStatus) => {
//     setLoading(true);
//     setError(null);
//     try {
//       const token = localStorage.getItem("authToken");
//       const response = await axios.get(`${API_BASE}/franchise-car-listings`, {
//         params: { status },
//         headers: { Authorization: `Bearer ${token}` },
//       });
//       setListings(response.data.data || []);
//     } catch (err) {
//       setError("Failed to fetch listings. Please try again.");
//       setListings([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchListings(activeTab);
//   }, [activeTab]);

//   const handleTabChange = (value: string) => {
//     setActiveTab(value as TabStatus);
//   };

//   const openDetails = (car: CarListing) => {
//     setSelectedCar(car);
//     setDetailsOpen(true);
//   };

//   const openReject = (car: CarListing) => {
//     setRejectCar(car);
//     setRejectReason("");
//     setRejectOpen(true);
//   };

//   const handleReject = async () => {
//     if (!rejectCar || !rejectReason.trim()) {
//       toast({
//         title: "Rejection reason required",
//         description: "Please provide a reason for rejection.",
//         variant: "destructive",
//       });
//       return;
//     }

//     setRejecting(true);
//     try {
//       const token = localStorage.getItem("authToken");
//       await axios.put(
//         `${API_BASE}/listings/reject/${rejectCar._id}`,
//         { reason: rejectReason },
//         { headers: { Authorization: `Bearer ${token}` } }
//       );

//       toast({
//         title: "Listing Rejected",
//         description: `${rejectCar.make} ${rejectCar.model} has been rejected.`,
//       });

//       setRejectOpen(false);
//       setRejectCar(null);
//       setRejectReason("");
//       fetchListings(activeTab);
//     } catch (err) {
//       toast({
//         title: "Error",
//         description: "Failed to reject listing. Please try again.",
//         variant: "destructive",
//       });
//     } finally {
//       setRejecting(false);
//     }
//   };

//   const formatPrice = (price: number) => {
//     return new Intl.NumberFormat("en-IN", {
//       style: "currency",
//       currency: "INR",
//       maximumFractionDigits: 0,
//     }).format(price);
//   };

//   const formatDate = (dateString: string) => {
//     return new Date(dateString).toLocaleDateString("en-IN", {
//       day: "numeric",
//       month: "short",
//       year: "numeric",
//     });
//   };

//   return (
//     <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
//       <div className="max-w-7xl mx-auto space-y-6">
//         {/* Header */}
//         <div className="animate-fade-in">
//           <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
//             Listing Verification
//           </h1>
//           <p className="text-muted-foreground mt-2">
//             Verify and manage car listings
//           </p>
//         </div>

//         {/* Tabs */}
//         <Tabs value={activeTab} onValueChange={handleTabChange} className="animate-slide-up">
//           <TabsList className="glass-card border border-border/50 p-1 h-auto flex-wrap gap-1">
//             <TabsTrigger
//               value="pending_verification"
//               className="data-[state=active]:bg-warning/20 data-[state=active]:text-warning rounded-lg px-4 py-2 transition-all"
//             >
//               <Clock className="w-4 h-4 mr-2" />
//               Pending
//             </TabsTrigger>
//             <TabsTrigger
//               value="approved"
//               className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary rounded-lg px-4 py-2 transition-all"
//             >
//               <CheckCircle2 className="w-4 h-4 mr-2" />
//               Approved
//             </TabsTrigger>
//             <TabsTrigger
//               value="live"
//               className="data-[state=active]:bg-success/20 data-[state=active]:text-success rounded-lg px-4 py-2 transition-all"
//             >
//               <CheckCircle2 className="w-4 h-4 mr-2" />
//               Live
//             </TabsTrigger>
//             <TabsTrigger
//               value="sold"
//               className="data-[state=active]:bg-success/20 data-[state=active]:text-success rounded-lg px-4 py-2 transition-all"
//             >
//               <ShoppingCart className="w-4 h-4 mr-2" />
//               Sold
//             </TabsTrigger>
//             <TabsTrigger
//               value="rejected"
//               className="data-[state=active]:bg-destructive/20 data-[state=active]:text-destructive rounded-lg px-4 py-2 transition-all"
//             >
//               <Ban className="w-4 h-4 mr-2" />
//               Rejected
//             </TabsTrigger>
//           </TabsList>

//           <TabsContent value={activeTab} className="mt-6">
//             {/* Loading State */}
//             {loading && (
//               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {[...Array(6)].map((_, i) => (
//                   <Card key={i} className="glass-card border border-border/50 overflow-hidden">
//                     <Skeleton className="h-48 w-full" />
//                     <CardContent className="p-4 space-y-3">
//                       <Skeleton className="h-6 w-3/4" />
//                       <Skeleton className="h-5 w-1/2" />
//                       <Skeleton className="h-4 w-full" />
//                       <div className="flex gap-2">
//                         <Skeleton className="h-6 w-16" />
//                         <Skeleton className="h-6 w-16" />
//                       </div>
//                     </CardContent>
//                   </Card>
//                 ))}
//               </div>
//             )}

//             {/* Error State */}
//             {error && !loading && (
//               <Card className="glass-card border border-destructive/30 p-8">
//                 <div className="flex flex-col items-center justify-center text-center space-y-4">
//                   <div className="p-4 rounded-full bg-destructive/10">
//                     <AlertCircle className="w-8 h-8 text-destructive" />
//                   </div>
//                   <div>
//                     <h3 className="text-lg font-semibold text-foreground">Something went wrong</h3>
//                     <p className="text-muted-foreground mt-1">{error}</p>
//                   </div>
//                   <Button
//                     onClick={() => fetchListings(activeTab)}
//                     variant="outline"
//                     className="gap-2"
//                   >
//                     <RefreshCw className="w-4 h-4" />
//                     Try Again
//                   </Button>
//                 </div>
//               </Card>
//             )}

//             {/* Empty State */}
//             {!loading && !error && listings.length === 0 && (
//               <Card className="glass-card border border-border/50 p-12">
//                 <div className="flex flex-col items-center justify-center text-center space-y-4">
//                   <div className="p-6 rounded-full bg-muted/50">
//                     <Car className="w-12 h-12 text-muted-foreground" />
//                   </div>
//                   <div>
//                     <h3 className="text-xl font-semibold text-foreground">No listings found</h3>
//                     <p className="text-muted-foreground mt-2">
//                       There are no {statusConfig[activeTab].label.toLowerCase()} listings at the moment.
//                     </p>
//                   </div>
//                 </div>
//               </Card>
//             )}

//             {/* Listings Grid */}
//             {!loading && !error && listings.length > 0 && (
//               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {listings.map((car, index) => (
//                   <Card
//                     key={car._id}
//                     className="glass-card border border-border/50 overflow-hidden group hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 animate-scale-in"
//                     style={{ animationDelay: `${index * 50}ms` }}
//                   >
//                     {/* Image */}
//                     <div className="relative h-48 overflow-hidden bg-muted/30">
//                       {car.images && car.images.length > 0 ? (
//                         <img
//                           src={car.images[0]}
//                           alt={`${car.make} ${car.model}`}
//                           className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
//                         />
//                       ) : (
//                         <div className="w-full h-full flex items-center justify-center">
//                           <ImageIcon className="w-16 h-16 text-muted-foreground/30" />
//                         </div>
//                       )}
//                       <Badge
//                         className={`absolute top-3 right-3 ${statusConfig[car.status].color} border backdrop-blur-sm`}
//                       >
//                         {statusConfig[car.status].icon}
//                         <span className="ml-1">{statusConfig[car.status].label}</span>
//                       </Badge>
//                     </div>

//                     <CardContent className="p-4 space-y-4">
//                       {/* Title & Price */}
//                       <div>
//                         <h3 className="text-lg font-semibold text-foreground truncate">
//                           {car.make} {car.model} {car.variant}
//                         </h3>
//                         <div className="flex items-center gap-2 mt-1">
//                           <span className="text-xl font-bold text-primary">
//                             {formatPrice(car.expectedPrice)}
//                           </span>
//                           {car.negotiable && (
//                             <Badge variant="secondary" className="text-xs">
//                               Negotiable
//                             </Badge>
//                           )}
//                         </div>
//                       </div>

//                       {/* Details */}
//                       <div className="space-y-2 text-sm text-muted-foreground">
//                         <div className="flex items-center gap-2">
//                           <MapPin className="w-4 h-4" />
//                           <span>{car.city}, {car.pincode}</span>
//                         </div>
//                         <div className="flex items-center gap-4">
//                           <div className="flex items-center gap-1">
//                             <Fuel className="w-4 h-4" />
//                             <span>{car.fuelType}</span>
//                           </div>
//                           <div className="flex items-center gap-1">
//                             <Gauge className="w-4 h-4" />
//                             <span>{car.transmission}</span>
//                           </div>
//                         </div>
//                         <div className="flex items-center gap-2">
//                           <Calendar className="w-4 h-4" />
//                           <span>{car.year} • {car.kmDriven?.toLocaleString()} km</span>
//                         </div>
//                       </div>

//                       {/* Badges */}
//                       <div className="flex flex-wrap gap-2">
//                         <Badge variant="outline" className="text-xs capitalize">
//                           {car.sellerType}
//                         </Badge>
//                         <Badge variant="outline" className="text-xs capitalize">
//                           {car.listingType}
//                         </Badge>
//                       </div>

//                       {/* Date */}
//                       <div className="text-xs text-muted-foreground flex items-center gap-1">
//                         <Clock className="w-3 h-3" />
//                         Listed on {formatDate(car.createdAt)}
//                       </div>

//                       {/* Actions - Only for Pending */}
//                       {activeTab === "pending_verification" && (
//                         <div className="flex gap-3 pt-2">
//                           <Button
//                             onClick={() => openDetails(car)}
//                             className="flex-1 gap-2"
//                             variant="outline"
//                           >
//                             <Eye className="w-4 h-4" />
//                             View Details
//                           </Button>
//                           <Button
//                             onClick={() => openReject(car)}
//                             variant="destructive"
//                             className="gap-2"
//                           >
//                             <XCircle className="w-4 h-4" />
//                             Reject
//                           </Button>
//                         </div>
//                       )}

//                       {/* View Details for other tabs */}
//                       {activeTab !== "pending_verification" && (
//                         <Button
//                           onClick={() => openDetails(car)}
//                           className="w-full gap-2"
//                           variant="outline"
//                         >
//                           <Eye className="w-4 h-4" />
//                           View Details
//                         </Button>
//                       )}
//                     </CardContent>
//                   </Card>
//                 ))}
//               </div>
//             )}
//           </TabsContent>
//         </Tabs>
//       </div>

//       {/* Details Dialog */}
//       <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
//         <DialogContent className="glass-card border border-border/50 max-w-3xl max-h-[90vh] overflow-y-auto">
//           {selectedCar && (
//             <>
//               <DialogHeader>
//                 <DialogTitle className="text-2xl font-bold">
//                   {selectedCar.make} {selectedCar.model} {selectedCar.variant}
//                 </DialogTitle>
//                 <DialogDescription>
//                   {selectedCar.year} • {selectedCar.kmDriven?.toLocaleString()} km driven
//                 </DialogDescription>
//               </DialogHeader>

//               <div className="space-y-6 py-4">
//                 {/* Image Gallery */}
//                 {selectedCar.images && selectedCar.images.length > 0 && (
//                   <div className="space-y-3">
//                     <h4 className="font-semibold text-foreground flex items-center gap-2">
//                       <ImageIcon className="w-4 h-4" />
//                       Photos ({selectedCar.images.length})
//                     </h4>
//                     <div className="grid grid-cols-3 gap-3">
//                       {selectedCar.images.map((img, i) => (
//                         <img
//                           key={i}
//                           src={img}
//                           alt={`Car image ${i + 1}`}
//                           className="w-full h-24 object-cover rounded-lg border border-border/50"
//                         />
//                       ))}
//                     </div>
//                   </div>
//                 )}

//                 {/* Seller Info */}
//                 <div className="glass p-4 rounded-xl space-y-3">
//                   <h4 className="font-semibold text-foreground">Seller Information</h4>
//                   <div className="grid grid-cols-2 gap-4 text-sm">
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <User className="w-4 h-4" />
//                       <span>{selectedCar.sellerName}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Phone className="w-4 h-4" />
//                       <span>{selectedCar.sellerMobile}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <MapPin className="w-4 h-4" />
//                       <span>{selectedCar.city}, {selectedCar.pincode}</span>
//                     </div>
//                     <div className="flex items-center gap-2">
//                       <Badge variant="outline" className="capitalize">
//                         {selectedCar.sellerType}
//                       </Badge>
//                       <Badge variant="outline" className="capitalize">
//                         {selectedCar.listingType}
//                       </Badge>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Car Specifications */}
//                 <div className="glass p-4 rounded-xl space-y-3">
//                   <h4 className="font-semibold text-foreground">Car Specifications</h4>
//                   <div className="grid grid-cols-2 gap-4 text-sm">
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Fuel className="w-4 h-4" />
//                       <span>Fuel: {selectedCar.fuelType}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Gauge className="w-4 h-4" />
//                       <span>Transmission: {selectedCar.transmission}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Users className="w-4 h-4" />
//                       <span>Owners: {selectedCar.noOfOwners}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Palette className="w-4 h-4" />
//                       <span>Color: {selectedCar.color}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Hash className="w-4 h-4" />
//                       <span>Reg: {selectedCar.registrationNumber}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <MapPin className="w-4 h-4" />
//                       <span>Reg City: {selectedCar.registrationCity}</span>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Price */}
//                 <div className="glass p-4 rounded-xl space-y-2">
//                   <h4 className="font-semibold text-foreground">Pricing</h4>
//                   <div className="flex items-center gap-3">
//                     <IndianRupee className="w-5 h-5 text-primary" />
//                     <span className="text-2xl font-bold text-primary">
//                       {formatPrice(selectedCar.expectedPrice)}
//                     </span>
//                     {selectedCar.negotiable && (
//                       <Badge variant="secondary">Negotiable</Badge>
//                     )}
//                   </div>
//                 </div>

//                 {/* Description */}
//                 {selectedCar.description && (
//                   <div className="space-y-2">
//                     <h4 className="font-semibold text-foreground">Description</h4>
//                     <p className="text-sm text-muted-foreground leading-relaxed">
//                       {selectedCar.description}
//                     </p>
//                   </div>
//                 )}

//                 {/* Documents */}
//                 {selectedCar.documents && selectedCar.documents.length > 0 && (
//                   <div className="space-y-3">
//                     <h4 className="font-semibold text-foreground flex items-center gap-2">
//                       <FileText className="w-4 h-4" />
//                       Documents ({selectedCar.documents.length})
//                     </h4>
//                     <div className="flex flex-wrap gap-2">
//                       {selectedCar.documents.map((doc, i) => (
//                         <a
//                           key={i}
//                           href={doc}
//                           target="_blank"
//                           rel="noopener noreferrer"
//                           className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors text-sm"
//                         >
//                           <FileText className="w-4 h-4" />
//                           Document {i + 1}
//                         </a>
//                       ))}
//                     </div>
//                   </div>
//                 )}

//                 {/* Inspection Video */}
//                 {selectedCar.inspectionVideo && (
//                   <div className="space-y-3">
//                     <h4 className="font-semibold text-foreground flex items-center gap-2">
//                       <Video className="w-4 h-4" />
//                       Inspection Video
//                     </h4>
//                     <video
//                       src={selectedCar.inspectionVideo}
//                       controls
//                       className="w-full rounded-xl border border-border/50"
//                     />
//                   </div>
//                 )}
//               </div>

//               <DialogFooter>
//                 <Button variant="outline" onClick={() => setDetailsOpen(false)}>
//                   Close
//                 </Button>
//               </DialogFooter>
//             </>
//           )}
//         </DialogContent>
//       </Dialog>

//       {/* Reject Dialog */}
//       <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
//         <DialogContent className="glass-card border border-border/50">
//           <DialogHeader>
//             <DialogTitle className="text-destructive flex items-center gap-2">
//               <XCircle className="w-5 h-5" />
//               Reject Listing
//             </DialogTitle>
//             <DialogDescription>
//               {rejectCar && (
//                 <>
//                   Are you sure you want to reject <strong>{rejectCar.make} {rejectCar.model}</strong>?
//                 </>
//               )}
//             </DialogDescription>
//           </DialogHeader>

//           <div className="py-4">
//             <Textarea
//               placeholder="Enter rejection reason (required)..."
//               value={rejectReason}
//               onChange={(e) => setRejectReason(e.target.value)}
//               className="min-h-[120px] bg-background/50 border-border/50 focus:border-primary/50"
//             />
//           </div>

//           <DialogFooter className="gap-3">
//             <Button
//               variant="outline"
//               onClick={() => setRejectOpen(false)}
//               disabled={rejecting}
//             >
//               Cancel
//             </Button>
//             <Button
//               variant="destructive"
//               onClick={handleReject}
//               disabled={rejecting || !rejectReason.trim()}
//               className="gap-2"
//             >
//               {rejecting ? (
//                 <>
//                   <Loader2 className="w-4 h-4 animate-spin" />
//                   Rejecting...
//                 </>
//               ) : (
//                 <>
//                   <XCircle className="w-4 h-4" />
//                   Reject Listing
//                 </>
//               )}
//             </Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>
//     </div>
//   );
// };

// export default ListingVerification;


// import { useState, useEffect } from "react";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
// import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
// import {
//   Dialog,
//   DialogContent,
//   DialogHeader,
//   DialogTitle,
//   DialogDescription,
//   DialogFooter,
// } from "@/components/ui/dialog";
// import { Textarea } from "@/components/ui/textarea";
// import { Skeleton } from "@/components/ui/skeleton";
// import { useToast } from "@/hooks/use-toast";
// import {
//   Car,
//   MapPin,
//   Fuel,
//   Calendar,
//   User,
//   Phone,
//   FileText,
//   Video,
//   X,
//   Eye,
//   XCircle,
//   ImageIcon,
//   AlertCircle,
//   RefreshCw,
//   Gauge,
//   Users,
//   Palette,
//   Hash,
//   IndianRupee,
//   Clock,
//   CheckCircle2,
//   Ban,
//   ShoppingCart,
//   Loader2,
// } from "lucide-react";

// // --- API Service Imports ---
// import { getFranchiseCarListings, rejectCarListing } from "@/services/franchiseService"; // Assuming these are in your franchiseService.js
// // You might also need a way to get the auth token, assuming it's in a utility or context
// import { getAuthToken } from "@/utils/auth"; // Placeholder, adjust path as needed


// interface CarListing {
//   _id: string;
//   sellerName: string;
//   sellerMobile: string;
//   city: string;
//   pincode: string;
//   make: string;
//   model: string;
//   variant: string;
//   year: number;
//   kmDriven: number;
//   fuelType: string;
//   rejectionReason?: string;
//   transmission: string;
//   registrationCity: string;
//   registrationNumber: string;
//   noOfOwners: number;
//   color: string;
//   expectedPrice: number;
//   negotiable: boolean;
//   description: string;
//   images: string[];
//   documents: string[];
//   inspectionVideo?: string;
//   sellerType: "franchise" | "individual";
//   listingType: "self" | "assisted";
//   status: "pending_verification" | "approved" | "live" | "sold" | "rejected";
//   qualityRating?: number;
//   createdAt: string;
// }

// type TabStatus = "pending_verification" | "approved" | "live" | "sold" | "rejected";

// const statusConfig: Record<TabStatus, { label: string; color: string; icon: React.ReactNode }> = {
//   pending_verification: { label: "Pending", color: "bg-warning/20 text-warning border-warning/30", icon: <Clock className="w-3 h-3" /> },
//   approved: { label: "Approved", color: "bg-primary/20 text-primary border-primary/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   live: { label: "Live", color: "bg-success/20 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   sold: { label: "Sold", color: "bg-success/20 text-success border-success/30", icon: <ShoppingCart className="w-3 h-3" /> },
//   rejected: { label: "Rejected", color: "bg-destructive/20 text-destructive border-destructive/30", icon: <Ban className="w-3 h-3" /> },
// };

// const ListingVerification = () => {
//   const { toast } = useToast();
//   const [activeTab, setActiveTab] = useState<TabStatus>("pending_verification");
//   const [listings, setListings] = useState<CarListing[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);

//   const [selectedCar, setSelectedCar] = useState<CarListing | null>(null);
//   const [detailsOpen, setDetailsOpen] = useState(false);

//   const [rejectCar, setRejectCar] = useState<CarListing | null>(null);
//   const [rejectOpen, setRejectOpen] = useState(false);
//   const [rejectReason, setRejectReason] = useState("");
//   const [rejecting, setRejecting] = useState(false);

//   // --- INTEGRATED API CALL for fetching listings ---
//   const fetchListings = async (status: TabStatus) => {
//     setLoading(true);
//     setError(null);
//     try {
//       const response = await getFranchiseCarListings(status);
//       if (response.success) {
//         setListings(response.data || []);
//       } else {
//         throw new Error(response.message || "Failed to fetch listings");
//       }
//     } catch (err: any) {
//       setError(err.message || "Failed to fetch listings. Please try again.");
//       setListings([]);
//       toast({
//         title: "Error",
//         description: err.message || "Failed to fetch listings.",
//         variant: "destructive",
//       });
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchListings(activeTab);
//   }, [activeTab]);

//   const handleTabChange = (value: string) => {
//     setActiveTab(value as TabStatus);
//   };

//   const openDetails = (car: CarListing) => {
//     setSelectedCar(car);
//     setDetailsOpen(true);
//   };

//   const openReject = (car: CarListing) => {
//     setRejectCar(car);
//     setRejectReason("");
//     setRejectOpen(true);
//   };

//   // --- INTEGRATED API CALL for rejecting a listing ---
//   const handleReject = async () => {
//     if (!rejectCar || !rejectReason.trim()) {
//       toast({
//         title: "Rejection reason required",
//         description: "Please provide a reason for rejection.",
//         variant: "destructive",
//       });
//       return;
//     }

//     setRejecting(true);
//     try {
//       const response = await rejectCarListing(rejectCar._id, rejectReason);
//       if (response.success) {
//         toast({
//           title: "Listing Rejected",
//           description: `${rejectCar.make} ${rejectCar.model} has been rejected.`,
//         });

//         setRejectOpen(false);
//         setRejectCar(null);
//         setRejectReason("");
//         fetchListings(activeTab); // Refresh listings to reflect the change
//       } else {
//         throw new Error(response.message || "Failed to reject listing.");
//       }
//     } catch (err: any) {
//       toast({
//         title: "Error",
//         description: err.message || "Failed to reject listing. Please try again.",
//         variant: "destructive",
//       });
//     } finally {
//       setRejecting(false);
//     }
//   };

//   const formatPrice = (price: number) => {
//     return new Intl.NumberFormat("en-IN", {
//       style: "currency",
//       currency: "INR",
//       maximumFractionDigits: 0,
//     }).format(price);
//   };

//   const formatDate = (dateString: string) => {
//     return new Date(dateString).toLocaleDateString("en-IN", {
//       day: "numeric",
//       month: "short",
//       year: "numeric",
//     });
//   };

//   return (
//     <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
//       <div className="max-w-7xl mx-auto space-y-6">
//         {/* Header */}
//         <div className="animate-fade-in">
//           <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
//             Listing Verification
//           </h1>
//           <p className="text-muted-foreground mt-2">
//             Verify and manage car listings
//           </p>
//         </div>

//         {/* Tabs */}
//         <Tabs value={activeTab} onValueChange={handleTabChange} className="animate-slide-up">
//           <TabsList className="glass-card border border-border/50 p-1 h-auto flex-wrap gap-1">
//             <TabsTrigger
//               value="pending_verification"
//               className="data-[state=active]:bg-warning/20 data-[state=active]:text-warning rounded-lg px-4 py-2 transition-all"
//             >
//               <Clock className="w-4 h-4 mr-2" />
//               Pending
//             </TabsTrigger>
//             <TabsTrigger
//               value="approved"
//               className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary rounded-lg px-4 py-2 transition-all"
//             >
//               <CheckCircle2 className="w-4 h-4 mr-2" />
//               Approved
//             </TabsTrigger>
//             <TabsTrigger
//               value="live"
//               className="data-[state=active]:bg-success/20 data-[state=active]:text-success rounded-lg px-4 py-2 transition-all"
//             >
//               <CheckCircle2 className="w-4 h-4 mr-2" />
//               Live
//             </TabsTrigger>
//             <TabsTrigger
//               value="sold"
//               className="data-[state=active]:bg-success/20 data-[state=active]:text-success rounded-lg px-4 py-2 transition-all"
//             >
//               <ShoppingCart className="w-4 h-4 mr-2" />
//               Sold
//             </TabsTrigger>
//             <TabsTrigger
//               value="rejected"
//               className="data-[state=active]:bg-destructive/20 data-[state=active]:text-destructive rounded-lg px-4 py-2 transition-all"
//             >
//               <Ban className="w-4 h-4 mr-2" />
//               Rejected
//             </TabsTrigger>
//           </TabsList>

//           <TabsContent value={activeTab} className="mt-6">
//             {/* Loading State */}
//             {loading && (
//               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {[...Array(6)].map((_, i) => (
//                   <Card key={i} className="glass-card border border-border/50 overflow-hidden">
//                     <Skeleton className="h-48 w-full" />
//                     <CardContent className="p-4 space-y-3">
//                       <Skeleton className="h-6 w-3/4" />
//                       <Skeleton className="h-5 w-1/2" />
//                       <Skeleton className="h-4 w-full" />
//                       <div className="flex gap-2">
//                         <Skeleton className="h-6 w-16" />
//                         <Skeleton className="h-6 w-16" />
//                       </div>
//                     </CardContent>
//                   </Card>
//                 ))}
//               </div>
//             )}

//             {/* Error State */}
//             {error && !loading && (
//               <Card className="glass-card border border-destructive/30 p-8">
//                 <div className="flex flex-col items-center justify-center text-center space-y-4">
//                   <div className="p-4 rounded-full bg-destructive/10">
//                     <AlertCircle className="w-8 h-8 text-destructive" />
//                   </div>
//                   <div>
//                     <h3 className="text-lg font-semibold text-foreground">Something went wrong</h3>
//                     <p className="text-muted-foreground mt-1">{error}</p>
//                   </div>
//                   <Button
//                     onClick={() => fetchListings(activeTab)}
//                     variant="outline"
//                     className="gap-2"
//                   >
//                     <RefreshCw className="w-4 h-4" />
//                     Try Again
//                   </Button>
//                 </div>
//               </Card>
//             )}

//             {/* Empty State */}
//             {!loading && !error && listings.length === 0 && (
//               <Card className="glass-card border border-border/50 p-12">
//                 <div className="flex flex-col items-center justify-center text-center space-y-4">
//                   <div className="p-6 rounded-full bg-muted/50">
//                     <Car className="w-12 h-12 text-muted-foreground" />
//                   </div>
//                   <div>
//                     <h3 className="text-xl font-semibold text-foreground">No listings found</h3>
//                     <p className="text-muted-foreground mt-2">
//                       There are no {statusConfig[activeTab].label.toLowerCase()} listings at the moment.
//                     </p>
//                   </div>
//                 </div>
//               </Card>
//             )}

//             {/* Listings Grid */}
//             {!loading && !error && listings.length > 0 && (
//               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {listings.map((car, index) => (
//                   <Card
//                     key={car._id}
//                     className="glass-card border border-border/50 overflow-hidden group hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 animate-scale-in"
//                     style={{ animationDelay: `${index * 50}ms` }}
//                   >
//                     {/* Image */}
//                     <div className="relative h-48 overflow-hidden bg-muted/30">
//                       {car.images && car.images.length > 0 ? (
//                         <img
//                           src={car.images[0]}
//                           alt={`${car.make} ${car.model}`}
//                           className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
//                         />
//                       ) : (
//                         <div className="w-full h-full flex items-center justify-center">
//                           <ImageIcon className="w-16 h-16 text-muted-foreground/30" />
//                         </div>
//                       )}
//                       <Badge
//                         className={`absolute top-3 right-3 ${statusConfig[car.status].color} border backdrop-blur-sm`}
//                       >
//                         {statusConfig[car.status].icon}
//                         <span className="ml-1">{statusConfig[car.status].label}</span>
//                       </Badge>
//                     </div>

//                     <CardContent className="p-4 space-y-4">
//                       {/* Title & Price */}
//                       <div>
//                         <h3 className="text-lg font-semibold text-foreground truncate">
//                           {car.make} {car.model} {car.variant}
//                         </h3>

//                     <div className="text-xl font-bold text-red-600">
//   <span>{car.rejectionReason}</span>
// </div>

//                         <div className="flex items-center gap-2 mt-1">
//                           <span className="text-xl font-bold text-primary">
//                             {formatPrice(car.expectedPrice)}
//                           </span>
//                           {car.negotiable && (
//                             <Badge variant="secondary" className="text-xs">
//                               Negotiable
//                             </Badge>
//                           )}
//                         </div>
//                       </div>

//                       {/* Details */}
//                       <div className="space-y-2 text-sm text-muted-foreground">
//                         <div className="flex items-center gap-2">
//                           <MapPin className="w-4 h-4" />
//                           <span>{car.city}, {car.pincode}</span>
//                         </div>
//                         <div className="flex items-center gap-4">
//                           <div className="flex items-center gap-1">
//                             <Fuel className="w-4 h-4" />
//                             <span>{car.fuelType}</span>
                                     
//                           </div>
                        
//                           <div className="flex items-center gap-1">
//                             <Gauge className="w-4 h-4" />
//                             <span>{car.transmission}</span>
//                           </div>
//                         </div>
//                         <div className="flex items-center gap-2">
//                           <Calendar className="w-4 h-4" />
//                           <span>{car.year} • {car.kmDriven?.toLocaleString()} km</span>
//                         </div>
//                       </div>

//                       {/* Badges */}
//                       <div className="flex flex-wrap gap-2">
//                         <Badge variant="outline" className="text-xs capitalize">
//                           {car.sellerType}
//                         </Badge>
//                         <Badge variant="outline" className="text-xs capitalize">
//                           {car.listingType}
//                         </Badge>
//                       </div>

//                       {/* Date */}
//                       <div className="text-xs text-muted-foreground flex items-center gap-1">
//                         <Clock className="w-3 h-3" />
//                         Listed on {formatDate(car.createdAt)}
//                       </div>

//                       {/* Actions - Only for Pending */}
//                       {activeTab === "pending_verification" && (
//                         <div className="flex gap-3 pt-2">
//                           <Button
//                             onClick={() => openDetails(car)}
//                             className="flex-1 gap-2"
//                             variant="outline"
//                           >
//                             <Eye className="w-4 h-4" />
//                             View Details
//                           </Button>
//                           <Button
//                             onClick={() => openReject(car)}
//                             variant="destructive"
//                             className="gap-2"
//                           >
//                             <XCircle className="w-4 h-4" />
//                             Reject
//                           </Button>
//                         </div>
//                       )}

//                       {/* View Details for other tabs */}
//                       {activeTab !== "pending_verification" && (
//                         <Button
//                           onClick={() => openDetails(car)}
//                           className="w-full gap-2"
//                           variant="outline"
//                         >
//                           <Eye className="w-4 h-4" />
//                           View Details
//                         </Button>
//                       )}
//                     </CardContent>
//                   </Card>
//                 ))}
//               </div>
//             )}
//           </TabsContent>
//         </Tabs>
//       </div>

//       {/* Details Dialog */}
//       <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
//         <DialogContent className="glass-card border border-border/50 max-w-3xl max-h-[90vh] overflow-y-auto">
//           {selectedCar && (
//             <>
//               <DialogHeader>
//                 <DialogTitle className="text-2xl font-bold">
//                   {selectedCar.make} {selectedCar.model} {selectedCar.variant}
//                 </DialogTitle>
//                 <DialogDescription>
//                   {selectedCar.year} • {selectedCar.kmDriven?.toLocaleString()} km driven
//                 </DialogDescription>
//               </DialogHeader>

//               <div className="space-y-6 py-4">
//                 {/* Image Gallery */}
//                 {selectedCar.images && selectedCar.images.length > 0 && (
//                   <div className="space-y-3">
//                     <h4 className="font-semibold text-foreground flex items-center gap-2">
//                       <ImageIcon className="w-4 h-4" />
//                       Photos ({selectedCar.images.length})
//                     </h4>
//                     <div className="grid grid-cols-3 gap-3">
//                       {selectedCar.images.map((img, i) => (
//                         <img
//                           key={i}
//                           src={img}
//                           alt={`Car image ${i + 1}`}
//                           className="w-full h-24 object-cover rounded-lg border border-border/50"
//                         />
//                       ))}
//                     </div>
//                   </div>
//                 )}

//                 {/* Seller Info */}
//                 <div className="glass p-4 rounded-xl space-y-3">
//                   <h4 className="font-semibold text-foreground">Seller Information</h4>
//                   <div className="grid grid-cols-2 gap-4 text-sm">
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <User className="w-4 h-4" />
//                       <span>{selectedCar.sellerName}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Phone className="w-4 h-4" />
//                       <span>{selectedCar.sellerMobile}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <MapPin className="w-4 h-4" />
//                       <span>{selectedCar.city}, {selectedCar.pincode}</span>
//                     </div>
//                     <div className="flex items-center gap-2">
//                       <Badge variant="outline" className="capitalize">
//                         {selectedCar.sellerType}
//                       </Badge>
//                       <Badge variant="outline" className="capitalize">
//                         {selectedCar.listingType}
//                       </Badge>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Car Specifications */}
//                 <div className="glass p-4 rounded-xl space-y-3">
//                   <h4 className="font-semibold text-foreground">Car Specifications</h4>
//                   <div className="grid grid-cols-2 gap-4 text-sm">
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Fuel className="w-4 h-4" />
//                       <span>Fuel: {selectedCar.fuelType}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Gauge className="w-4 h-4" />
//                       <span>Transmission: {selectedCar.transmission}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Users className="w-4 h-4" />
//                       <span>Owners: {selectedCar.noOfOwners}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Palette className="w-4 h-4" />
//                       <span>Color: {selectedCar.color}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <Hash className="w-4 h-4" />
//                       <span>Reg: {selectedCar.registrationNumber}</span>
//                     </div>
//                     <div className="flex items-center gap-2 text-muted-foreground">
//                       <MapPin className="w-4 h-4" />
//                       <span>Reg City: {selectedCar.registrationCity}</span>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Price */}
//                 <div className="glass p-4 rounded-xl space-y-2">
//                   <h4 className="font-semibold text-foreground">Pricing</h4>
//                   <div className="flex items-center gap-3">
//                     <IndianRupee className="w-5 h-5 text-primary" />
//                     <span className="text-2xl font-bold text-primary">
//                       {formatPrice(selectedCar.expectedPrice)}
//                     </span>
//                     {selectedCar.negotiable && (
//                       <Badge variant="secondary">Negotiable</Badge>
//                     )}
//                   </div>
//                 </div>

//                 {/* Description */}
//                 {selectedCar.description && (
//                   <div className="space-y-2">
//                     <h4 className="font-semibold text-foreground">Description</h4>
//                     <p className="text-sm text-muted-foreground leading-relaxed">
//                       {selectedCar.description}
//                     </p>
//                   </div>
//                 )}

//                 {/* Documents */}
//                 {selectedCar.documents && selectedCar.documents.length > 0 && (
//                   <div className="space-y-3">
//                     <h4 className="font-semibold text-foreground flex items-center gap-2">
//                       <FileText className="w-4 h-4" />
//                       Documents ({selectedCar.documents.length})
//                     </h4>
//                     <div className="flex flex-wrap gap-2">
//                       {selectedCar.documents.map((doc, i) => (
//                         <a
//                           key={i}
//                           href={doc}
//                           target="_blank"
//                           rel="noopener noreferrer"
//                           className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-muted/50 hover:bg-muted transition-colors text-sm"
//                         >
//                           <FileText className="w-4 h-4" />
//                           Document {i + 1}
//                         </a>
//                       ))}
//                     </div>
//                   </div>
//                 )}

//                 {/* Inspection Video */}
//                 {selectedCar.inspectionVideo && (
//                   <div className="space-y-3">
//                     <h4 className="font-semibold text-foreground flex items-center gap-2">
//                       <Video className="w-4 h-4" />
//                       Inspection Video
//                     </h4>
//                     <video
//                       src={selectedCar.inspectionVideo}
//                       controls
//                       className="w-full rounded-xl border border-border/50"
//                     />
//                   </div>
//                 )}
//               </div>

//               <DialogFooter>
//                 <Button variant="outline" onClick={() => setDetailsOpen(false)}>
//                   Close
//                 </Button>
//               </DialogFooter>
//             </>
//           )}
//         </DialogContent>
//       </Dialog>

//       {/* Reject Dialog */}
//       <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
//         <DialogContent className="glass-card border border-border/50">
//           <DialogHeader>
//             <DialogTitle className="text-destructive flex items-center gap-2">
//               <XCircle className="w-5 h-5" />
//               Reject Listing
//             </DialogTitle>
//             <DialogDescription>
//               {rejectCar && (
//                 <>
//                   Are you sure you want to reject <strong>{rejectCar.make} {rejectCar.model}</strong>?
//                 </>
//               )}
//             </DialogDescription>
//           </DialogHeader>

//           <div className="py-4">
//             <Textarea
//               placeholder="Enter rejection reason (required)..."
//               value={rejectReason}
//               onChange={(e) => setRejectReason(e.target.value)}
//               className="min-h-[120px] bg-background/50 border-border/50 focus:border-primary/50"
//             />
//           </div>

//           <DialogFooter className="gap-3">
//             <Button
//               variant="outline"
//               onClick={() => setRejectOpen(false)}
//               disabled={rejecting}
//             >
//               Cancel
//             </Button>
//             <Button
//               variant="destructive"
//               onClick={handleReject}
//               disabled={rejecting || !rejectReason.trim()}
//               className="gap-2"
//             >
//               {rejecting ? (
//                 <>
//                   <Loader2 className="w-4 h-4 animate-spin" />
//                   Rejecting...
//                 </>
//               ) : (
//                 <>
//                   <XCircle className="w-4 h-4" />
//                   Reject Listing
//                 </>
//               )}
//             </Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>
//     </div>
//   );
// };

// export default ListingVerification;





















// import { useState, useEffect } from "react";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
// import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
// import {
//   Dialog,
//   DialogContent,
//   DialogHeader,
//   DialogTitle,
//   DialogDescription,
//   DialogFooter,
// } from "@/components/ui/dialog";
// import { Textarea } from "@/components/ui/textarea";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { Skeleton } from "@/components/ui/skeleton";
// import { useToast } from "@/hooks/use-toast";
// import {
//   Car,
//   MapPin,
//   Fuel,
//   Calendar,
//   User,
//   Phone,
//   FileText,
//   Video,
//   X,
//   Eye,
//   XCircle,
//   ImageIcon,
//   AlertCircle,
//   RefreshCw,
//   Gauge,
//   Users,
//   Palette,
//   Hash,
//   IndianRupee,
//   Clock,
//   CheckCircle2,
//   Ban,
//   ShoppingCart,
//   Loader2,
//   Edit3,
//   Check,
// } from "lucide-react";

// // --- API Service Imports ---
// import { 
//   getFranchiseCarListings, 
//   rejectCarListing, 
//   approveCarListing, 
//   editFranchiseListing 
// } from "@/services/franchiseService"; 

// interface CarListing {
//   _id: string;
//   sellerName: string;
//   sellerMobile: string;
//   city: string;
//   pincode: string;
//   make: string;
//   model: string;
//   variant: string;
//   year: number;
//   kmDriven: number;
//   fuelType: string;
//   rejectionReason?: string;
//   approvalRemark?: string; // For comments in approved section
//   transmission: string;
//   registrationCity: string;
//   registrationNumber: string;
//   noOfOwners: number;
//   color: string;
//   expectedPrice: number;
//   negotiable: boolean;
//   description: string;
//   images: string[];
//   documents: string[];
//   inspectionVideo?: string;
//   sellerType: "franchise" | "individual";
//   listingType: "self" | "assisted";
//   status: "pending_verification" | "approved" | "live" | "sold" | "rejected";
//   qualityRating?: number;
//   createdAt: string;
// }

// type TabStatus = "pending_verification" | "approved" | "live" | "sold" | "rejected";

// const statusConfig: Record<TabStatus, { label: string; color: string; icon: React.ReactNode }> = {
//   pending_verification: { label: "Pending", color: "bg-warning/20 text-warning border-warning/30", icon: <Clock className="w-3 h-3" /> },
//   approved: { label: "Approved", color: "bg-primary/20 text-primary border-primary/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   live: { label: "Live", color: "bg-success/20 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   sold: { label: "Sold", color: "bg-success/20 text-success border-success/30", icon: <ShoppingCart className="w-3 h-3" /> },
//   rejected: { label: "Rejected", color: "bg-destructive/20 text-destructive border-destructive/30", icon: <Ban className="w-3 h-3" /> },
// };

// const ListingVerification = () => {
//   const { toast } = useToast();
//   const [activeTab, setActiveTab] = useState<TabStatus>("pending_verification");
//   const [listings, setListings] = useState<CarListing[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);

//   // View Details State
//   const [selectedCar, setSelectedCar] = useState<CarListing | null>(null);
//   const [detailsOpen, setDetailsOpen] = useState(false);

//   // Rejection State
//   const [rejectCar, setRejectCar] = useState<CarListing | null>(null);
//   const [rejectOpen, setRejectOpen] = useState(false);
//   const [rejectReason, setRejectReason] = useState("");
//   const [rejecting, setRejecting] = useState(false);

//   // Approval State
//   const [approveCar, setApproveCar] = useState<CarListing | null>(null);
//   const [approveOpen, setApproveOpen] = useState(false);
//   const [approveComment, setApproveComment] = useState("");
//   const [approving, setApproving] = useState(false);

//   // Edit State
//   const [editCar, setEditCar] = useState<CarListing | null>(null);
//   const [editOpen, setEditOpen] = useState(false);
//   const [editing, setEditing] = useState(false);
//   const [editForm, setEditForm] = useState({
//     make: "",
//     model: "",
//     variant: "",
//     year: 0,
//     kmDriven: 0,
//     expectedPrice: 0,
//   });

//   const fetchListings = async (status: TabStatus) => {
//     setLoading(true);
//     setError(null);
//     try {
//       const response = await getFranchiseCarListings(status);
//       if (response.success) {
//         setListings(response.data || []);
//       } else {
//         throw new Error(response.message || "Failed to fetch listings");
//       }
//     } catch (err: any) {
//       setError(err.message || "Failed to fetch listings. Please try again.");
//       setListings([]);
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchListings(activeTab);
//   }, [activeTab]);

//   const handleTabChange = (value: string) => {
//     setActiveTab(value as TabStatus);
//   };

//   // --- Handlers ---
//   const handleReject = async () => {
//     if (!rejectCar || !rejectReason.trim()) return;
//     setRejecting(true);
//     try {
//       const response = await rejectCarListing(rejectCar._id, rejectReason);
//       if (response.success) {
//         toast({ title: "Listing Rejected", description: "Successfully rejected." });
//         setRejectOpen(false);
//         fetchListings(activeTab);
//       }
//     } catch (err: any) {
//       toast({ title: "Error", description: err.message, variant: "destructive" });
//     } finally {
//       setRejecting(false);
//     }
//   };

//   const handleApprove = async () => {
//     if (!approveCar || !approveComment.trim()) return;
//     setApproving(true);
//     try {
//       const response = await approveCarListing(approveCar._id, approveComment);
//       if (response.success) {
//         toast({ title: "Listing Approved", description: "Listing is now Live." });
//         setApproveOpen(false);
//         setApproveComment("");
//         fetchListings(activeTab);
//       }
//     } catch (err: any) {
//       toast({ title: "Error", description: err.message, variant: "destructive" });
//     } finally {
//       setApproving(false);
//     }
//   };

//   const openEdit = (car: CarListing) => {
//     setEditCar(car);
//     setEditForm({
//       make: car.make,
//       model: car.model,
//       variant: car.variant,
//       year: car.year,
//       kmDriven: car.kmDriven,
//       expectedPrice: car.expectedPrice,
//     });
//     setEditOpen(true);
//   };

//   const handleEditSubmit = async () => {
//     if (!editCar) return;
//     setEditing(true);
//     try {
//       const response = await editFranchiseListing(editCar._id, editForm);
//       if (response.success) {
//         toast({ title: "Updated", description: "Listing updated successfully." });
//         setEditOpen(false);
//         fetchListings(activeTab);
//       }
//     } catch (err: any) {
//       toast({ title: "Error", description: err.message, variant: "destructive" });
//     } finally {
//       setEditing(false);
//     }
//   };

//   const formatPrice = (price: number) => {
//     return new Intl.NumberFormat("en-IN", {
//       style: "currency",
//       currency: "INR",
//       maximumFractionDigits: 0,
//     }).format(price);
//   };

//   const formatDate = (dateString: string) => {
//     return new Date(dateString).toLocaleDateString("en-IN", {
//       day: "numeric", month: "short", year: "numeric",
//     });
//   };

//   return (
//     <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
//       <div className="max-w-7xl mx-auto space-y-6">
//         <div className="animate-fade-in">
//           <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">Listing Verification</h1>
//           <p className="text-muted-foreground mt-2">Verify and manage car listings</p>
//         </div>

//         <Tabs value={activeTab} onValueChange={handleTabChange} className="animate-slide-up">
//           <TabsList className="glass-card border border-border/50 p-1 h-auto flex-wrap gap-1">
//             {Object.keys(statusConfig).map((key) => (
//               <TabsTrigger
//                 key={key}
//                 value={key}
//                 className={`data-[state=active]:${statusConfig[key as TabStatus].color} rounded-lg px-4 py-2 transition-all`}
//               >
//                 {statusConfig[key as TabStatus].icon}
//                 <span className="ml-2">{statusConfig[key as TabStatus].label}</span>
//               </TabsTrigger>
//             ))}
//           </TabsList>

//           <TabsContent value={activeTab} className="mt-6">
//             {loading && (
//               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {[...Array(6)].map((_, i) => (
//                   <Card key={i} className="glass-card border border-border/50 overflow-hidden">
//                     <Skeleton className="h-48 w-full" />
//                     <CardContent className="p-4 space-y-3">
//                       <Skeleton className="h-6 w-3/4" /><Skeleton className="h-5 w-1/2" />
//                     </CardContent>
//                   </Card>
//                 ))}
//               </div>
//             )}

//             {!loading && listings.length > 0 && (
//               <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//                 {listings.map((car, index) => (
//                   <Card
//                     key={car._id}
//                     className="glass-card border border-border/50 overflow-hidden group hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 animate-scale-in"
//                     style={{ animationDelay: `${index * 50}ms` }}
//                   >
//                     <div className="relative h-48 overflow-hidden bg-muted/30">
//                       {car.images?.length > 0 ? (
//                         <img src={car.images[0]} alt={car.model} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
//                       ) : (
//                         <div className="w-full h-full flex items-center justify-center"><ImageIcon className="w-16 h-16 text-muted-foreground/30" /></div>
//                       )}
//                       <Badge className={`absolute top-3 right-3 ${statusConfig[car.status].color} border backdrop-blur-sm`}>
//                         {statusConfig[car.status].icon}
//                         <span className="ml-1">{statusConfig[car.status].label}</span>
//                       </Badge>
//                     </div>

//                     <CardContent className="p-4 space-y-4">
//                       <div>
//                         <h3 className="text-lg font-semibold text-foreground truncate">{car.make} {car.model} {car.variant}</h3>
                        
//                         {/* Status Comments Logic */}
//                         {car.rejectionReason && activeTab === "rejected" && (
//                           <div className="text-sm font-bold text-destructive mt-1">Reason: {car.rejectionReason}</div>
//                         )}
//                         {car.approvalRemark && (activeTab === "approved" || activeTab === "live") && (
//                           <div className="text-sm font-bold text-primary mt-1 italic">Remark: {car.approvalRemark}</div>
//                         )}

//                         <div className="flex items-center gap-2 mt-1">
//                           <span className="text-xl font-bold text-primary">{formatPrice(car.expectedPrice)}</span>
//                           {car.negotiable && <Badge variant="secondary" className="text-xs">Negotiable</Badge>}
//                         </div>
//                       </div>

//                       <div className="space-y-2 text-sm text-muted-foreground">
//                         <div className="flex items-center gap-2"><MapPin className="w-4 h-4" /><span>{car.city}, {car.pincode}</span></div>
//                         <div className="flex items-center gap-4">
//                           <div className="flex items-center gap-1"><Fuel className="w-4 h-4" /><span>{car.fuelType}</span></div>
//                           <div className="flex items-center gap-1"><Gauge className="w-4 h-4" /><span>{car.transmission}</span></div>
//                         </div>
//                         <div className="flex items-center gap-2"><Calendar className="w-4 h-4" /><span>{car.year} • {car.kmDriven?.toLocaleString()} km</span></div>
//                       </div>

//                       <div className="flex flex-wrap gap-2">
//                         <Badge variant="outline" className="text-xs capitalize">{car.sellerType}</Badge>
//                         <Badge variant="outline" className="text-xs capitalize">{car.listingType}</Badge>
//                       </div>

//                       <div className="text-xs text-muted-foreground flex items-center gap-1">
//                         <Clock className="w-3 h-3" /> Listed on {formatDate(car.createdAt)}
//                       </div>

//                       {/* --- Pending Verification Actions --- */}
//                       {activeTab === "pending_verification" ? (
//                         <div className="grid grid-cols-2 gap-2 pt-2">
//                           <Button onClick={() => { setSelectedCar(car); setDetailsOpen(true); }} className="gap-2" variant="outline" size="sm">
//                             <Eye className="w-4 h-4" /> Details
//                           </Button>
//                           <Button onClick={() => openEdit(car)} variant="outline" size="sm" className="gap-2 border-primary/50 text-primary">
//                             <Edit3 className="w-4 h-4" /> Edit
//                           </Button>
//                           <Button onClick={() => { setApproveCar(car); setApproveOpen(true); }} size="sm" className="gap-2 bg-success hover:bg-success/90">
//                             <Check className="w-4 h-4" /> Approve
//                           </Button>
//                           <Button onClick={() => { setRejectCar(car); setRejectOpen(true); }} variant="destructive" size="sm" className="gap-2">
//                             <XCircle className="w-4 h-4" /> Reject
//                           </Button>
//                         </div>
//                       ) : (
//                         <Button onClick={() => { setSelectedCar(car); setDetailsOpen(true); }} className="w-full gap-2" variant="outline">
//                           <Eye className="w-4 h-4" /> View Details
//                         </Button>
//                       )}
//                     </CardContent>
//                   </Card>
//                 ))}
//               </div>
//             )}
//           </TabsContent>
//         </Tabs>
//       </div>

//       {/* --- Details Dialog (Untouched UI) --- */}
//       <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
//         <DialogContent className="glass-card border border-border/50 max-w-3xl max-h-[90vh] overflow-y-auto">
//           {selectedCar && (
//             <>
//               <DialogHeader>
//                 <DialogTitle className="text-2xl font-bold">{selectedCar.make} {selectedCar.model} {selectedCar.variant}</DialogTitle>
//                 <DialogDescription>{selectedCar.year} • {selectedCar.kmDriven?.toLocaleString()} km driven</DialogDescription>
//               </DialogHeader>
//               <div className="space-y-6 py-4">
//                 {/* Image Gallery */}
//                 <div className="grid grid-cols-3 gap-3">
//                   {selectedCar.images?.map((img, i) => (
//                     <img key={i} src={img} alt="car" className="w-full h-24 object-cover rounded-lg border border-border/50" />
//                   ))}
//                 </div>

//                 {/* Approved Remark Display */}
//                 {selectedCar.approvalRemark && (
//                   <div className="glass p-4 rounded-xl border border-primary/20 bg-primary/5">
//                     <h4 className="font-semibold text-primary flex items-center gap-2 mb-1">
//                       <CheckCircle2 className="w-4 h-4" /> Approval Remark
//                     </h4>
//                     <p className="text-sm text-foreground">{selectedCar.approvalRemark}</p>
//                   </div>
//                 )}

//                 {/* Seller Info */}
//                 <div className="glass p-4 rounded-xl space-y-3">
//                   <h4 className="font-semibold text-foreground">Seller Information</h4>
//                   <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
//                     <div className="flex items-center gap-2"><User className="w-4 h-4" /><span>{selectedCar.sellerName}</span></div>
//                     <div className="flex items-center gap-2"><Phone className="w-4 h-4" /><span>{selectedCar.sellerMobile}</span></div>
//                     <div className="flex items-center gap-2"><MapPin className="w-4 h-4" /><span>{selectedCar.city}, {selectedCar.pincode}</span></div>
//                     <div className="flex gap-2">
//                       <Badge variant="outline" className="capitalize">{selectedCar.sellerType}</Badge>
//                       <Badge variant="outline" className="capitalize">{selectedCar.listingType}</Badge>
//                     </div>
//                   </div>
//                 </div>

//                 {/* Specs */}
//                 <div className="glass p-4 rounded-xl space-y-3">
//                   <h4 className="font-semibold text-foreground">Car Specifications</h4>
//                   <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
//                     <div className="flex items-center gap-2"><Fuel className="w-4 h-4" /><span>Fuel: {selectedCar.fuelType}</span></div>
//                     <div className="flex items-center gap-2"><Gauge className="w-4 h-4" /><span>Transmission: {selectedCar.transmission}</span></div>
//                     <div className="flex items-center gap-2"><Users className="w-4 h-4" /><span>Owners: {selectedCar.noOfOwners}</span></div>
//                     <div className="flex items-center gap-2"><Palette className="w-4 h-4" /><span>Color: {selectedCar.color}</span></div>
//                     <div className="flex items-center gap-2"><Hash className="w-4 h-4" /><span>Reg: {selectedCar.registrationNumber}</span></div>
//                     <div className="flex items-center gap-2"><MapPin className="w-4 h-4" /><span>Reg City: {selectedCar.registrationCity}</span></div>
//                   </div>
//                 </div>

//                 {/* Pricing */}
//                 <div className="glass p-4 rounded-xl flex items-center gap-3">
//                   <IndianRupee className="w-5 h-5 text-primary" />
//                   <span className="text-2xl font-bold text-primary">{formatPrice(selectedCar.expectedPrice)}</span>
//                   {selectedCar.negotiable && <Badge variant="secondary">Negotiable</Badge>}
//                 </div>

//                 {/* Description */}
//                 {selectedCar.description && (
//                   <div className="space-y-2">
//                     <h4 className="font-semibold text-foreground">Description</h4>
//                     <p className="text-sm text-muted-foreground leading-relaxed">{selectedCar.description}</p>
//                   </div>
//                 )}
//               </div>
//               <DialogFooter><Button variant="outline" onClick={() => setDetailsOpen(false)}>Close</Button></DialogFooter>
//             </>
//           )}
//         </DialogContent>
//       </Dialog>

//       {/* --- Approve Dialog (Matches Main UI Style) --- */}
//       <Dialog open={approveOpen} onOpenChange={setApproveOpen}>
//         <DialogContent className="glass-card border border-border/50">
//           <DialogHeader>
//             <DialogTitle className="text-primary flex items-center gap-2">
//               <CheckCircle2 className="w-5 h-5" /> Approve Listing
//             </DialogTitle>
//           </DialogHeader>
//           <div className="py-4 space-y-3">
//             <Label>Verification Comment (Internal)</Label>
//             <Textarea 
//               placeholder="e.g. Engine checked, RC verified..." 
//               value={approveComment} 
//               onChange={(e) => setApproveComment(e.target.value)}
//               className="min-h-[120px] bg-background/50"
//             />
//           </div>
//           <DialogFooter>
//             <Button variant="outline" onClick={() => setApproveOpen(false)}>Cancel</Button>
//             <Button onClick={handleApprove} disabled={approving || !approveComment.trim()} className="bg-success hover:bg-success/90">
//               {approving ? <Loader2 className="w-4 h-4 animate-spin" /> : "Approve"}
//             </Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>

//       {/* --- Edit Dialog (Matches Main UI Style) --- */}
//       <Dialog open={editOpen} onOpenChange={setEditOpen}>
//         <DialogContent className="glass-card border border-border/50 max-w-lg">
//           <DialogHeader><DialogTitle>Edit Listing Details</DialogTitle></DialogHeader>
//           <div className="grid grid-cols-2 gap-4 py-4">
//             <div className="space-y-1"><Label>Make</Label><Input value={editForm.make} onChange={(e) => setEditForm({...editForm, make: e.target.value})} /></div>
//             <div className="space-y-1"><Label>Model</Label><Input value={editForm.model} onChange={(e) => setEditForm({...editForm, model: e.target.value})} /></div>
//             <div className="space-y-1"><Label>Variant</Label><Input value={editForm.variant} onChange={(e) => setEditForm({...editForm, variant: e.target.value})} /></div>
//             <div className="space-y-1"><Label>Year</Label><Input type="number" value={editForm.year} onChange={(e) => setEditForm({...editForm, year: parseInt(e.target.value)})} /></div>
//             <div className="space-y-1"><Label>KM Driven</Label><Input type="number" value={editForm.kmDriven} onChange={(e) => setEditForm({...editForm, kmDriven: parseInt(e.target.value)})} /></div>
//             <div className="space-y-1"><Label>Price (₹)</Label><Input type="number" value={editForm.expectedPrice} onChange={(e) => setEditForm({...editForm, expectedPrice: parseInt(e.target.value)})} /></div>
//           </div>
//           <DialogFooter>
//             <Button variant="outline" onClick={() => setEditOpen(false)}>Cancel</Button>
//             <Button onClick={handleEditSubmit} disabled={editing}>{editing ? "Saving..." : "Save Changes"}</Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>

//       {/* --- Reject Dialog (Untouched UI) --- */}
//       <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
//         <DialogContent className="glass-card border border-border/50">
//           <DialogHeader>
//             <DialogTitle className="text-destructive flex items-center gap-2"><XCircle className="w-5 h-5" /> Reject Listing</DialogTitle>
//           </DialogHeader>
//           <div className="py-4">
//             <Textarea 
//               placeholder="Enter rejection reason (required)..." 
//               value={rejectReason} 
//               onChange={(e) => setRejectReason(e.target.value)}
//               className="min-h-[120px] bg-background/50"
//             />
//           </div>
//           <DialogFooter className="gap-3">
//             <Button variant="outline" onClick={() => setRejectOpen(false)}>Cancel</Button>
//             <Button variant="destructive" onClick={handleReject} disabled={rejecting || !rejectReason.trim()}>
//               {rejecting ? <Loader2 className="w-4 h-4 animate-spin" /> : "Reject Listing"}
//             </Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>
//     </div>
//   );
// };

// export default ListingVerification;






// import { useState, useEffect } from "react";
// import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
// import { useToast } from "@/hooks/use-toast";
// import { Clock, CheckCircle2, Ban, ShoppingCart } from "lucide-react";

// // --- API Service Imports ---
// import { getFranchiseCarListings, rejectCarListing } from "@/services/franchiseService";

// // Child Components
// import { ListingGrid } from "../franchise/pages/ListingGrid";
// import { DetailsDialog, RejectDialog } from "../franchise/pages/ListingDialogs";

// type TabStatus = "pending_verification" | "approved" | "live" | "sold" | "rejected";

// const statusConfig: Record<
//   TabStatus,
//   { label: string; color: string; icon: React.ReactNode }
// > = {
//   pending_verification: { label: "Pending", color: "bg-warning/20 text-warning border-warning/30", icon: <Clock className="w-3 h-3" /> },
//   approved: { label: "Approved", color: "bg-primary/20 text-primary border-primary/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   live: { label: "Live", color: "bg-success/20 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
//   sold: { label: "Sold", color: "bg-success/20 text-success border-success/30", icon: <ShoppingCart className="w-3 h-3" /> },
//   rejected: { label: "Rejected", color: "bg-destructive/20 text-destructive border-destructive/30", icon: <Ban className="w-3 h-3" /> },
// };

// const ListingVerification = () => {
//   const { toast } = useToast();
//   const [activeTab, setActiveTab] = useState<TabStatus>("pending_verification");
//   const [listings, setListings] = useState<any[]>([]);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);

//   const [selectedCar, setSelectedCar] = useState<any | null>(null);
//   const [detailsOpen, setDetailsOpen] = useState(false);

//   const [rejectCar, setRejectCar] = useState<any | null>(null);
//   const [rejectOpen, setRejectOpen] = useState(false);
//   const [rejectReason, setRejectReason] = useState("");
//   const [rejecting, setRejecting] = useState(false);

//   // --- API CALL for fetching listings ---
//   const fetchListings = async (status: TabStatus) => {
//     setLoading(true);
//     setError(null);
//     try {
//       const response = await getFranchiseCarListings(status);
//       if (response.success) {
//         setListings(response.data || []);
//       } else {
//         throw new Error(response.message || "Failed to fetch listings");
//       }
//     } catch (err: any) {
//       setError(err.message || "Failed to fetch listings. Please try again.");
//       setListings([]);
//       toast({
//         title: "Error",
//         description: err.message || "Failed to fetch listings.",
//         variant: "destructive",
//       });
//     } finally {
//       setLoading(false);
//     }
//   };

//   useEffect(() => {
//     fetchListings(activeTab);
//   }, [activeTab]);

//   const handleTabChange = (value: string) => {
//     setActiveTab(value as TabStatus);
//   };

//   const openDetails = (car: any) => {
//     setSelectedCar(car);
//     setDetailsOpen(true);
//   };

//   const openReject = (car: any) => {
//     setRejectCar(car);
//     setRejectReason("");
//     setRejectOpen(true);
//   };

//   // --- API CALL for rejecting a listing ---
//   const handleReject = async () => {
//     if (!rejectCar || !rejectReason.trim()) {
//       toast({
//         title: "Rejection reason required",
//         description: "Please provide a reason for rejection.",
//         variant: "destructive",
//       });
//       return;
//     }

//     setRejecting(true);
//     try {
//       const response = await rejectCarListing(rejectCar._id, rejectReason);
//       if (response.success) {
//         toast({
//           title: "Listing Rejected",
//           description: `${rejectCar.make} ${rejectCar.model} has been rejected.`,
//         });

//         setRejectOpen(false);
//         setRejectCar(null);
//         setRejectReason("");
//         fetchListings(activeTab); // Refresh listings
//       } else {
//         throw new Error(response.message || "Failed to reject listing.");
//       }
//     } catch (err: any) {
//       toast({
//         title: "Error",
//         description: err.message || "Failed to reject listing. Please try again.",
//         variant: "destructive",
//       });
//     } finally {
//       setRejecting(false);
//     }
//   };

//   return (
//     <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
//       <div className="max-w-7xl mx-auto space-y-6">
//         {/* Header */}
//         <div className="animate-fade-in">
//           <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">
//             Listing Verification
//           </h1>
//           <p className="text-muted-foreground mt-2">
//             Verify and manage car listings
//           </p>
//         </div>

//         {/* Tabs */}
//         <Tabs value={activeTab} onValueChange={handleTabChange} className="animate-slide-up">
//           <TabsList className="glass-card border border-border/50 p-1 h-auto flex-wrap gap-1">
//             <TabsTrigger value="pending_verification" className="data-[state=active]:bg-warning/20 data-[state=active]:text-warning rounded-lg px-4 py-2 transition-all">
//               <Clock className="w-4 h-4 mr-2" /> Pending
//             </TabsTrigger>
//             {/* <TabsTrigger value="approved" className="data-[state=active]:bg-primary/20 data-[state=active]:text-primary rounded-lg px-4 py-2 transition-all">
//               <CheckCircle2 className="w-4 h-4 mr-2" /> Approved
//             </TabsTrigger> */}
//             <TabsTrigger value="live" className="data-[state=active]:bg-success/20 data-[state=active]:text-success rounded-lg px-4 py-2 transition-all">
//               <CheckCircle2 className="w-4 h-4 mr-2" /> Live
//             </TabsTrigger>
//             <TabsTrigger value="sold" className="data-[state=active]:bg-success/20 data-[state=active]:text-success rounded-lg px-4 py-2 transition-all">
//               <ShoppingCart className="w-4 h-4 mr-2" /> Sold
//             </TabsTrigger>
//             <TabsTrigger value="rejected" className="data-[state=active]:bg-destructive/20 data-[state=active]:text-destructive rounded-lg px-4 py-2 transition-all">
//               <Ban className="w-4 h-4 mr-2" /> Rejected
//             </TabsTrigger>
//           </TabsList>

//           <TabsContent value={activeTab} className="mt-6">
//             <ListingGrid 
//               loading={loading}
//               error={error}
//               listings={listings}
//               activeTab={activeTab}
//               onRetry={() => fetchListings(activeTab)}
//               onView={openDetails}
//               onReject={openReject}
//               statusConfig={statusConfig}
//             />
//           </TabsContent>
//         </Tabs>
//       </div>

//       {/* Modals */}
//       <DetailsDialog 
//         open={detailsOpen} 
//         onOpenChange={setDetailsOpen} 
//         car={selectedCar} 
//       />

//       <RejectDialog 
//         open={rejectOpen} 
//         onOpenChange={setRejectOpen}
//         car={rejectCar}
//         reason={rejectReason}
//         setReason={setRejectReason}
//         onConfirm={handleReject}
//         loading={rejecting}
//       />
//     </div>
//   );
// };

// export default ListingVerification;


 
// import { useState, useEffect } from "react";
// import { Card, CardContent } from "@/components/ui/card";
// import { Button } from "@/components/ui/button";
// import { Badge } from "@/components/ui/badge";
// import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
// import {
//   Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter,
// } from "@/components/ui/dialog";
// import { Input } from "@/components/ui/input";
// import { Label } from "@/components/ui/label";
// import { Skeleton } from "@/components/ui/skeleton";
// import { useToast } from "@/hooks/use-toast";
// import {
//   Eye, XCircle, Loader2, UserPlus, CalendarDays,
//   Check, ClipboardCheck, User, Phone, FileText,
//   CheckCircle2, AlertCircle, Gauge, CarFront
// } from "lucide-react";
 
// import {
//   getFranchiseCarListings,
//   approveCarListing,
//   scheduleInspection,
//   assignInspector,
//   getMyInspectors,
//   getCompletedInspectionByCarId, // Make sure this is exported in your service
// } from "@/services/franchiseService";
 
// const ListingVerification = () => {
//   const { toast } = useToast();
 
//   const [activeTab, setActiveTab] = useState("pending_verification");
//   const [listings, setListings] = useState([]);
//   const [inspectors, setInspectors] = useState([]);
//   const [loading, setLoading] = useState(true);
 
//   // Dialog open/close states
//   const [selectedCar, setSelectedCar] = useState(null);
//   const [scheduleOpen, setScheduleOpen] = useState(false);
//   const [assignOpen, setAssignOpen] = useState(false);
//   const [approveOpen, setApproveOpen] = useState(false);
//   const [reportOpen, setReportOpen] = useState(false);
 
//   // Data states
//   const [scheduleData, setScheduleData] = useState({ date: "", time: "" });
//   const [selectedInspectorId, setSelectedInspectorId] = useState("");
//   const [qualityRating, setQualityRating] = useState(5);
//   const [reportData, setReportData] = useState(null);
//   const [reportLoading, setReportLoading] = useState(false);
 
//   // ---------------- FETCH DATA ----------------
//   const fetchData = async () => {
//     setLoading(true);
//     try {
//       const res = await getFranchiseCarListings(activeTab);
//       setListings(res.data || []);
 
//       const ins = await getMyInspectors();
//       setInspectors(ins.data || []);
//     } catch (err) {
//       toast({ title: "Failed to load listings", variant: "destructive" });
//     } finally {
//       setLoading(false);
//     }
//   };
 
//   useEffect(() => {
//     fetchData();
//   }, [activeTab]);
 
//   // ---------------- HELPERS ----------------
//   const getInspectorName = (id) =>
//     inspectors.find(i => i._id === id)?.fullName || "Inspector";
 
//   const getInspectorPhone = (id) =>
//     inspectors.find(i => i._id === id)?.phone || "N/A";
 
//   const formatDate = (d) =>
//     new Date(d).toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
 
//   // ---------------- ACTIONS ----------------
 
//   // Naya Function: Inspection Report Dekhne Ke Liye
//   const handleViewReport = async (carId) => {
//     setReportLoading(true);
//     setReportOpen(true);
//     try {
//       const res = await getCompletedInspectionByCarId(carId);
//       setReportData(res.data);
//     } catch (error) {
//       toast({ title: "Report fetch karne mein error aayi", variant: "destructive" });
//       setReportOpen(false);
//     } finally {
//       setReportLoading(false);
//     }
//   };
 
//   const handleSchedule = async () => {
//     try {
//       await scheduleInspection({ carId: selectedCar._id, ...scheduleData });
//       toast({ title: "Inspection scheduled successfully" });
//       setScheduleOpen(false);
//       fetchData();
//     } catch {
//       toast({ title: "Schedule failed", variant: "destructive" });
//     }
//   };
 
//   const handleAssign = async () => {
//     try {
//       await assignInspector({ carId: selectedCar._id, inspectorId: selectedInspectorId });
//       toast({ title: "Inspector assigned successfully" });
//       setAssignOpen(false);
//       fetchData();
//     } catch {
//       toast({ title: "Assignment failed", variant: "destructive" });
//     }
//   };
 
//   const handleApprove = async () => {
//     try {
//       // selectedCar humne report modal ya direct card se set kiya hoga
//       await approveCarListing(selectedCar._id, qualityRating);
//       toast({ title: "Car is now LIVE for buyers! 🚀" });
//       setApproveOpen(false);
//       setReportOpen(false);
//       fetchData();
//     } catch {
//       toast({ title: "Approval failed", variant: "destructive" });
//     }
//   };
  
//   // ---------------- UI ----------------
//   return (
//     <div className="p-6 max-w-7xl mx-auto space-y-6">
//       <div className="flex justify-between items-center">
//         <h1 className="text-3xl font-bold">Listing & Inspection Management</h1>
//         <Button onClick={fetchData} variant="outline" size="sm">Refresh</Button>
//       </div>
 
//       <Tabs value={activeTab} onValueChange={setActiveTab}>
//         <TabsList className="bg-slate-100 p-1">
//           {["pending_verification", "approved", "live", "rejected", "sold"].map(t => (
//             <TabsTrigger key={t} value={t} className="capitalize">
//               {t.replace("_", " ")}
//             </TabsTrigger>
//           ))}
//         </TabsList>
 
//         <TabsContent value={activeTab} className="mt-6">
//           {loading ? (
//             <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
//               {[1, 2, 3].map(i => <Skeleton key={i} className="h-80 w-full rounded-xl" />)}
//             </div>
//           ) : listings.length === 0 ? (
//             <div className="text-center py-20 text-muted-foreground border-2 border-dashed rounded-xl">
//               No cars found in this category.
//             </div>
//           ) : (
//             <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
//               {listings.map(car => (
//                 <Card key={car._id} className="overflow-hidden border-none shadow-lg hover:shadow-xl transition-shadow">
//                   <div className="h-48 relative">
//                     <img src={car.images?.[0] || "https://placehold.co/600x400?text=No+Image"} className="w-full h-full object-cover" alt="car" />
//                     <Badge className="absolute top-3 right-3 capitalize shadow-md" variant={car.inspectionStatus === 'completed' ? 'success' : 'secondary'}>
//                       {car.inspectionStatus}
//                     </Badge>
//                     <Badge className="absolute top-1  capitalize shadow-md" variant={car.inspectionStatus === 'completed' ? 'success' : 'secondary'}>
//                       {car.status}
//                     </Badge>
//                   </div>
 
//                   <CardContent className="p-5 space-y-4">
//                     <div>
//                       <h3 className="font-bold text-xl">{car.make} {car.model}</h3>
//                       <p className="text-sm text-muted-foreground font-medium">
//                         {car.year} • {car.fuelType} • {car.kmsDriven?.toLocaleString()} km
//                       </p>
//                     </div>
 
//                     {/* INSPECTION BADGE INFO */}
//                     {(car.scheduledDate || car.assignedInspector) && (
//                       <div className="bg-blue-50 border border-blue-100 rounded-lg p-3 space-y-1.5 text-xs text-blue-800">
//                         <p className="font-bold flex items-center gap-1.5">
//                           <ClipboardCheck className="w-4 h-4" /> Inspection Details
//                         </p>
//                         {car.scheduledDate && (
//                           <p className="flex items-center gap-1 font-medium">
//                             <CalendarDays className="w-3.5 h-3.5" /> {formatDate(car.scheduledDate)} at {car.scheduledTime}
//                           </p>
//                         )}
//                         {car.assignedInspector && (
//                           <div className="flex flex-col gap-1">
//                             <p className="flex items-center gap-1"><User className="w-3.5 h-3.5" /> {getInspectorName(car.assignedInspector)}</p>
//                             <p className="flex items-center gap-1"><Phone className="w-3.5 h-3.5" /> {getInspectorPhone(car.assignedInspector)}</p>
//                           </div>
//                         )}
//                       </div>
//                     )}
 
//                     {/* STATUS BASED ACTIONS */}
//                     <div className="space-y-2 pt-2">
//                       {car.inspectionStatus === "pending" && (
//                         <Button className="w-full" onClick={() => { setSelectedCar(car); setScheduleOpen(true); }}>
//                           <CalendarDays className="w-4 h-4 mr-2" /> Schedule Now
//                         </Button>
//                       )}
 
//                       {car.inspectionStatus === "user_accepted" && (
//                         <Button className="w-full bg-purple-600 hover:bg-purple-700" onClick={() => { setSelectedCar(car); setAssignOpen(true); }}>
//                           <UserPlus className="w-4 h-4 mr-2" /> Assign Inspector
//                         </Button>
//                       )}
 
//                       {car.inspectionStatus === "completed" && car.status !== "live" && (
//                         <Button className="w-full bg-blue-600 hover:bg-blue-700 font-bold" onClick={() => handleViewReport(car._id)}>
//                           <FileText className="w-4 h-4 mr-2" /> View Report & Make Live
//                         </Button>
//                       )}
 
//                       <div className="grid grid-cols-2 gap-2">
//                         <Button variant="outline" size="sm" className="w-full">
//                           <Eye className="w-4 h-4 mr-2" /> Details
//                         </Button>
//                         <Button variant="ghost" size="sm" className="w-full text-destructive hover:bg-red-50">
//                           <XCircle className="w-4 h-4 mr-2" /> Reject
//                         </Button>
//                       </div>
//                     </div>
//                   </CardContent>
//                 </Card>
//               ))}
//             </div>
//           )}
//         </TabsContent>
//       </Tabs>
 
//       {/* ------------------- DIALOGS (MODALS) ------------------- */}
 
//       {/* 1. VIEW INSPECTION REPORT DIALOG */}
//       <Dialog open={reportOpen} onOpenChange={setReportOpen}>
//         <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
//           <DialogHeader>
//             <DialogTitle className="text-2xl flex items-center gap-2">
//               <ClipboardCheck className="text-blue-600 w-6 h-6" />
//               Inspection Report
//             </DialogTitle>
//           </DialogHeader>
 
//           {reportLoading ? (
//             <div className="py-20 flex flex-col items-center justify-center gap-4">
//               <Loader2 className="w-10 h-10 animate-spin text-blue-600" />
//               <p className="text-muted-foreground font-medium">Fetching inspection details...</p>
//             </div>
//           ) : reportData ? (
//             <div className="space-y-6">
 
//               {/* Seller & Car Details */}
// <div className="space-y-4 bg-white p-4 rounded-xl border">
//   <h4 className="font-bold text-sm mb-2 underline underline-offset-4">Seller & Car Details</h4>
//   <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
//     <div className="text-sm text-slate-600 space-y-1">
//       <p><b>Seller Name:</b> {reportData.sellerName}</p>
//       <p><b>Mobile:</b> {reportData.sellerMobile}</p>
//       {reportData.sellerEmail && <p><b>Email:</b> {reportData.sellerEmail}</p>}
//       <p><b>City:</b> {reportData.city}</p>
//       <p><b>Pincode:</b> {reportData.pincode}</p>
//           <p><b>Make:</b> {reportData.make}</p>
//       <p><b>Model:</b> {reportData.model}</p>
//       <p><b>Variant:</b> {reportData.variant}</p>
//     </div>
//     <div className="text-sm text-slate-600 space-y-1">
 
//       <p><b>Year:</b> {reportData.year}</p>
//       <p><b>Kilometers Driven:</b> {reportData.kmDriven}</p>
//       <p><b>Fuel Type:</b> {reportData.fuelType}</p>
//       <p><b>Transmission:</b> {reportData.transmission}</p>
//       <p><b>Registration City:</b> {reportData.registrationCity}</p>
//       <p><b>Registration Number:</b> {reportData.registrationNumber}</p>
//       <p><b>No. of Owners:</b> {reportData.noOfOwners}</p>
//       <p><b>Expected Price:</b> ₹{reportData.expectedPrice?.toLocaleString()} {reportData.negotiable ? "(Negotiable)" : "(Fixed)"}</p>
//     </div>
//   </div>
//   {reportData.description && (
//     <p className="text-sm text-slate-600 mt-2"><b>Description:</b> {reportData.description}</p>
//   )}
//   {reportData.images?.length > 0 && (
//     <div className="grid grid-cols-2 md:grid-cols-4 gap-2 mt-3">
//       {reportData.images.map((img, idx) => (
//         <img key={idx} src={img} alt="car" className="rounded-lg border object-cover h-30 w-full" />
//       ))}
//     </div>
//   )}
 
//   {/* Listed By Info */}
// {reportData.listedBy && (
//   <div className="bg-slate-50 p-4 rounded-xl border mt-4 text-sm text-slate-600">
//     <h4 className="font-bold text-sm mb-2 underline underline-offset-4">Listed By</h4>
//     <p><b>ID:</b> {reportData.listedBy._id.slice(-6)}</p>
//     <p><b>Email:</b> {reportData.listedBy.email}</p>
//     <p><b>Phone:</b> {reportData.listedBy.phone}</p>
//   </div>
// )}
// </div>
 
             
//               {/* Summary Header */}
//               <div className="grid grid-cols-2 gap-4 bg-slate-50 p-4 rounded-xl border">
//                 <div>
//                   <Label className="text-xs uppercase text-slate-500">Vehicle Info</Label>
//                   <p className="font-bold text-lg">{reportData.make} {reportData.model}</p>
//                   <p className="text-sm text-slate-600">{reportData.year} Model • ₹{reportData.expectedPrice?.toLocaleString()}</p>
//                 </div>
//                 <div>
//                   <Label className="text-xs uppercase text-slate-500">Inspector Info</Label>
//                   <p className="font-bold text-lg">{reportData.inspectionReport?.inspectorName}</p>
//                       <p className="font-bold text-sm">{reportData.inspectionReport.inspector?.phone}</p>
//                   <p className="text-sm text-slate-600">ID: {reportData.inspectionReport?.inspector?._id.slice(-6)}</p>
//                 </div>
//               </div>
 
//               {/* Health Scores */}
//               <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
//                 {[
//                   { label: "Exterior", score: reportData.inspectionReport?.exteriorScore, icon: CarFront },
//                   { label: "Interior", score: reportData.inspectionReport?.interiorScore, icon: User },
//                   { label: "Engine", score: reportData.inspectionReport?.engineMechanicalScore, icon: Gauge },
//                   { label: "Tyres", score: reportData.inspectionReport?.tyresBrakesScore, icon: Gauge },
//                 ].map((item) => (
//                   <div key={item.label} className="bg-white border-2 border-slate-100 rounded-xl p-3 text-center">
//                     <p className="text-[10px] font-bold uppercase text-slate-400 mb-1">{item.label}</p>
//                     <p className="text-2xl font-black text-blue-600">{item.score}<span className="text-xs text-slate-400">/10</span></p>
//                   </div>
//                 ))}
//               </div>
 
//               {/* Technical Details */}
//               <div className="space-y-3 bg-slate-50 p-4 rounded-xl border">
//                 <h4 className="font-bold text-sm flex items-center gap-2 underline underline-offset-4">
//                   Technical Checklist
//                 </h4>
//                 <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
//                   <div className="flex items-center gap-2 text-sm">
//                     <CheckCircle2 className="w-4 h-4 text-green-500" />
//                     <span className="text-slate-600">Odometer: <b>{reportData.inspectionReport?.odometerReading} km</b></span>
//                   </div>
//                   <div className="flex items-center gap-2 text-sm">
//                     <CheckCircle2 className="w-4 h-4 text-green-500" />
//                     <span className="text-slate-600">Tyre Condition: <b>{reportData.inspectionReport?.tyreCondition}</b></span>
//                   </div>
//                   <div className="flex items-center gap-2 text-sm">
//                     <AlertCircle className="w-4 h-4 text-orange-500" />
//                     <span className="text-slate-600">Accident History: <b>{reportData.inspectionReport?.accidentHistory}</b></span>
//                   </div>
//                   <div className="flex items-center gap-2 text-sm">
//                     <CheckCircle2 className="w-4 h-4 text-green-500" />
//                     <span className="text-slate-600">VIN Verified: <b>{reportData.inspectionReport?.vinChassisVerified ? "Yes" : "No"}</b></span>
//                   </div>
//                 </div>
//                 <div className="mt-3 p-3 bg-orange-100/50 border border-orange-200 rounded-lg">
//                   <p className="text-xs font-bold text-orange-800 uppercase">Inspector's Remarks:</p>
//                   <p className="text-sm text-orange-900 mt-1 italic">"{reportData.inspectionReport?.minorIssues || "No major issues reported by inspector."}"</p>
//                 </div>
//               </div>
 
 
//                 {/* 📸 PHOTOS */}
//         {reportData.inspectionReport?.photos?.length > 0 && (
//           <div>
//             <h4 className="font-bold text-sm mb-2">Inspection Photos</h4>
//             <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
//               {reportData.inspectionReport.photos.map((img, i) => (
//                 <img
//                   key={i}
//                   src={img}
//                   alt="inspection"
//                   className="rounded-lg border object-cover h-32 w-full"
//                 />
//               ))}
//             </div>
//           </div>
//         )}
 
 
//               <DialogFooter className="flex gap-2">
//                 <Button variant="outline" onClick={() => setReportOpen(false)} className="flex-1">Close</Button>
//                 <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white font-bold"
//                   onClick={() => {
//                     setSelectedCar(reportData);
//                     setApproveOpen(true);
//                   }}>
//                   <Check className="w-4 h-4 mr-2" /> Approve & Go Live
//                 </Button>
//               </DialogFooter>
//             </div>
//           ) : (
//             <div className="text-center py-10">Report data not found.</div>
//           )}
//         </DialogContent>
//       </Dialog>
 
//       {/* 2. SCHEDULE INSPECTION DIALOG */}
//       <Dialog open={scheduleOpen} onOpenChange={setScheduleOpen}>
//         <DialogContent className="sm:max-w-[425px]">
//           <DialogHeader><DialogTitle>Schedule Inspection</DialogTitle></DialogHeader>
//           <div className="grid gap-4 py-4">
//             <div className="space-y-2">
//               <Label>Date</Label>
//               <Input type="date" className="w-full" onChange={e => setScheduleData({ ...scheduleData, date: e.target.value })} />
//             </div>
//             <div className="space-y-2">
//               <Label>Time Slot</Label>
//               <Input type="time" className="w-full" onChange={e => setScheduleData({ ...scheduleData, time: e.target.value })} />
//             </div>
//           </div>
//           <DialogFooter>
//             <Button onClick={handleSchedule} className="w-full">Send Schedule to User</Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>
 
//       {/* 3. ASSIGN INSPECTOR DIALOG */}
//       <Dialog open={assignOpen} onOpenChange={setAssignOpen}>
//         <DialogContent>
//           <DialogHeader><DialogTitle>Select Inspector</DialogTitle></DialogHeader>
//           <div className="py-4">
//             <select
//               className="w-full border p-3 rounded-lg bg-white shadow-sm focus:ring-2 focus:ring-blue-500"
//               onChange={e => setSelectedInspectorId(e.target.value)}
//               value={selectedInspectorId}
//             >
//               <option value="">-- Choose an Inspector --</option>
//               {inspectors.map(i => (
//                 <option key={i._id} value={i._id}>{i.fullName} ({i.phone})</option>
//               ))}
//             </select>
//           </div>
//           <DialogFooter>
//             <Button onClick={handleAssign} disabled={!selectedInspectorId} className="w-full bg-purple-600">
//               Confirm Assignment
//             </Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>
 
//       {/* 4. FINAL APPROVAL DIALOG (MAKE LIVE) */}
//       <Dialog open={approveOpen} onOpenChange={setApproveOpen}>
//         <DialogContent>
//           <DialogHeader>
//             <DialogTitle>Final Approval: Go Live</DialogTitle>
//           </DialogHeader>
//           <div className="space-y-5 py-4">
//             <div className="space-y-2">
//               <Label className="font-bold">Assign Quality Rating (1-10)</Label>
//               <Input
//                 type="number"
//                 min={1}
//                 max={10}
//                 value={qualityRating}
//                 onChange={e => setQualityRating(parseInt(e.target.value))}
//                 className="text-lg font-bold"
//               />
//               <p className="text-xs text-muted-foreground italic">Higher rating helps in faster sales.</p>
//             </div>
           
//             <div className="p-3 bg-green-50 rounded-lg border border-green-200">
//               <p className="text-sm text-green-800 flex gap-2">
//                 <CheckCircle2 className="w-5 h-5" />
//                 This car will be listed on the main marketplace for all customers to see.
//               </p>
//             </div>
//           </div>
//           <DialogFooter>
//             <Button onClick={handleApprove} className="w-full bg-green-600 hover:bg-green-700 h-12 text-lg">
//               🚀 Publish Listing Now
//             </Button>
//           </DialogFooter>
//         </DialogContent>
//       </Dialog>
//     </div>
//   );
// };
 
// export default ListingVerification;
 





import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from "@/components/ui/dialog";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import {
  Car,
  MapPin,
  Fuel,
  Calendar,
  User,
  Phone,
  FileText,
  X,
  Eye,
  XCircle,
  ImageIcon,
  Gauge,
  Users,
  Palette,
  Hash,
  IndianRupee,
  Clock,
  CheckCircle2,
  Ban,
  ShoppingCart,
  Loader2,
  Edit3,
  Check,
  CalendarDays,
  UserPlus,
  ClipboardCheck,
  CarFront,
  Mail
} from "lucide-react";

// --- API Service Imports ---
import { 
  getFranchiseCarListings, 
  rejectCarListing, 
  approveCarListing, 
  editFranchiseListing,
  scheduleInspection,
  assignInspector,
  getMyInspectors,
  getCompletedInspectionByCarId
} from "@/services/franchiseService"; 

interface CarListing {
  _id: string;
  sellerName: string;
  sellerMobile: string;
  sellerEmail?: string;
  city: string;
  pincode: string;
  make: string;
  model: string;
  variant: string;
  year: number;
  kmDriven: number;
  fuelType: string;
  rejectionReason?: string;
  approvalRemark?: string;
  transmission: string;
  registrationCity: string;
  registrationNumber: string;
  noOfOwners: number;
  color: string;
  expectedPrice: number;
  negotiable: boolean;
  description: string;
  images: string[];
  documents: string[];
  inspectionVideo?: string;
  sellerType: "franchise" | "individual";
  listingType: "self" | "assisted";
  status: "pending_verification" | "approved" | "live" | "sold" | "rejected";
  qualityRating?: number;
  createdAt: string;
  
  // Inspection Fields
  inspectionStatus?: "pending" | "scheduled" | "user_accepted" | "assigned" | "completed";
  scheduledDate?: string;
  scheduledTime?: string;
  assignedInspector?: string;
  
  // Report Data
  inspectionReport?: any;
  listedBy?: any;
}

type TabStatus = "pending_verification" | "approved" | "live" | "sold" | "rejected";

const statusConfig: Record<TabStatus, { label: string; color: string; icon: React.ReactNode }> = {
  pending_verification: { label: "Pending", color: "bg-warning/20 text-warning border-warning/30", icon: <Clock className="w-3 h-3" /> },
  approved: { label: "Approved", color: "bg-primary/20 text-primary border-primary/30", icon: <CheckCircle2 className="w-3 h-3" /> },
  live: { label: "Live", color: "bg-success/20 text-success border-success/30", icon: <CheckCircle2 className="w-3 h-3" /> },
  sold: { label: "Sold", color: "bg-success/20 text-success border-success/30", icon: <ShoppingCart className="w-3 h-3" /> },
  rejected: { label: "Rejected", color: "bg-destructive/20 text-destructive border-destructive/30", icon: <Ban className="w-3 h-3" /> },
};

const ListingVerification = () => {
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<TabStatus>("pending_verification");
  const [listings, setListings] = useState<CarListing[]>([]);
  const [inspectors, setInspectors] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // View Details State
  const [selectedCar, setSelectedCar] = useState<CarListing | null>(null);
  const [detailsOpen, setDetailsOpen] = useState(false);

  // Rejection State
  const [rejectCar, setRejectCar] = useState<CarListing | null>(null);
  const [rejectOpen, setRejectOpen] = useState(false);
  const [rejectReason, setRejectReason] = useState("");
  const [rejecting, setRejecting] = useState(false);

  // Approval State
  const [approveCar, setApproveCar] = useState<CarListing | null>(null);
  const [approveOpen, setApproveOpen] = useState(false);
  const [qualityRating, setQualityRating] = useState(5);
  const [approving, setApproving] = useState(false);

  // Edit State
  const [editCar, setEditCar] = useState<CarListing | null>(null);
  const [editOpen, setEditOpen] = useState(false);
  const [editing, setEditing] = useState(false);
  const [editForm, setEditForm] = useState({
    make: "", model: "", variant: "", year: 0, kmDriven: 0, expectedPrice: 0,
  });

  // Action States
  const [scheduleOpen, setScheduleOpen] = useState(false);
  const [scheduleData, setScheduleData] = useState({ date: "", time: "" });
  const [assignOpen, setAssignOpen] = useState(false);
  const [selectedInspectorId, setSelectedInspectorId] = useState("");
  const [reportOpen, setReportOpen] = useState(false);
  const [reportData, setReportData] = useState<CarListing | null>(null);
  const [reportLoading, setReportLoading] = useState(false);

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await getFranchiseCarListings(activeTab);
      if (res.success) setListings(res.data || []);
      
      if (activeTab === "pending_verification") {
        const ins = await getMyInspectors();
        setInspectors(ins.data || []);
      }
    } catch (err: any) {
      // Silent fail or minimal toast
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, [activeTab]);

  const handleTabChange = (value: string) => setActiveTab(value as TabStatus);

  // Helpers
  const getInspectorName = (id: string) => inspectors.find(i => i._id === id)?.fullName || "Inspector";
  const getInspectorPhone = (id: string) => inspectors.find(i => i._id === id)?.phone || "N/A";
  const formatPrice = (price: number) => new Intl.NumberFormat("en-IN", { style: "currency", currency: "INR", maximumFractionDigits: 0 }).format(price);
  const formatDate = (dateString: string) => new Date(dateString).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });

  // Handlers
  const handleSchedule = async () => {
    if(!selectedCar) return;
    try {
      await scheduleInspection({ carId: selectedCar._id, ...scheduleData });
      toast({ title: "Inspection Scheduled", description: "Request sent to user." });
      setScheduleOpen(false);
      fetchData();
    } catch (err) { toast({ title: "Error", variant: "destructive" }); }
  };

  const handleAssign = async () => {
    if(!selectedCar || !selectedInspectorId) return;
    try {
      await assignInspector({ carId: selectedCar._id, inspectorId: selectedInspectorId });
      toast({ title: "Inspector Assigned" });
      setAssignOpen(false);
      fetchData();
    } catch (err) { toast({ title: "Error", variant: "destructive" }); }
  };

  const handleViewReport = async (carId: string) => {
    setReportLoading(true);
    setReportOpen(true);
    try {
      const res = await getCompletedInspectionByCarId(carId);
      setReportData(res.data);
    } catch (error) {
      toast({ title: "Failed to fetch report", variant: "destructive" });
      setReportOpen(false);
    } finally {
      setReportLoading(false);
    }
  };

  const handleApprove = async () => {
    const targetCar = approveCar || selectedCar || reportData;
    if (!targetCar) return;
    setApproving(true);
    try {
      await approveCarListing(targetCar._id, qualityRating);
      toast({ title: "Car Published Successfully! 🚀" });
      setApproveOpen(false);
      setReportOpen(false);
      fetchData();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setApproving(false);
    }
  };

  const handleReject = async () => {
    if (!rejectCar || !rejectReason.trim()) return;
    setRejecting(true);
    try {
      const response = await rejectCarListing(rejectCar._id, rejectReason);
      if (response.success) {
        toast({ title: "Listing Rejected" });
        setRejectOpen(false);
        fetchData();
      }
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setRejecting(false);
    }
  };

  const openEdit = (car: CarListing) => {
    setEditCar(car);
    setEditForm({
      make: car.make, model: car.model, variant: car.variant,
      year: car.year, kmDriven: car.kmDriven, expectedPrice: car.expectedPrice,
    });
    setEditOpen(true);
  };

  const handleEditSubmit = async () => {
    if (!editCar) return;
    setEditing(true);
    try {
      await editFranchiseListing(editCar._id, editForm);
      toast({ title: "Updated Successfully" });
      setEditOpen(false);
      fetchData();
    } catch (err: any) {
      toast({ title: "Error", description: err.message, variant: "destructive" });
    } finally {
      setEditing(false);
    }
  };

  return (
    <div className="min-h-screen bg-background p-4 md:p-6 lg:p-8">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="animate-fade-in">
          <h1 className="text-3xl md:text-4xl font-bold text-foreground tracking-tight">Listing Verification</h1>
          <p className="text-muted-foreground mt-2">Manage inspections and approvals</p>
        </div>

        <Tabs value={activeTab} onValueChange={handleTabChange} className="animate-slide-up">
          <TabsList className="glass-card border border-border/50 p-1 h-auto flex-wrap gap-1">
            {Object.keys(statusConfig).map((key) => (
              <TabsTrigger
                key={key}
                value={key}
                className={`data-[state=active]:${statusConfig[key as TabStatus].color} rounded-lg px-4 py-2 transition-all`}
              >
                {statusConfig[key as TabStatus].icon}
                <span className="ml-2">{statusConfig[key as TabStatus].label}</span>
              </TabsTrigger>
            ))}
          </TabsList>

          <TabsContent value={activeTab} className="mt-6">
            {loading && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[...Array(6)].map((_, i) => (
                  <Card key={i} className="glass-card border border-border/50 overflow-hidden"><Skeleton className="h-48 w-full" /><CardContent className="p-4 space-y-3"><Skeleton className="h-6 w-3/4" /></CardContent></Card>
                ))}
              </div>
            )}

            {!loading && listings.length > 0 && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {listings.map((car, index) => (
                  <Card key={car._id} className="glass-card border border-border/50 overflow-hidden group hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5 animate-scale-in" style={{ animationDelay: `${index * 50}ms` }}>
                    <div className="relative h-48 overflow-hidden bg-muted/30">
                      {car.images?.length > 0 ? (
                        <img src={car.images[0]} alt={car.model} className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105" />
                      ) : (
                        <div className="w-full h-full flex items-center justify-center"><ImageIcon className="w-16 h-16 text-muted-foreground/30" /></div>
                      )}
                      <Badge className={`absolute top-3 right-3 ${statusConfig[car.status].color} border backdrop-blur-sm`}>{statusConfig[car.status].label}</Badge>
                      {car.inspectionStatus && car.status === 'pending_verification' && (
                        <Badge className="absolute top-3 left-3 bg-blue-500/80 backdrop-blur-sm text-white border-none capitalize">{car.inspectionStatus.replace("_", " ")}</Badge>
                      )}
                    </div>

                    <CardContent className="p-4 space-y-4">
                      <div>
                        <h3 className="text-lg font-semibold text-foreground truncate">{car.make} {car.model} {car.variant}</h3>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-xl font-bold text-primary">{formatPrice(car.expectedPrice)}</span>
                        </div>
                      </div>

                      <div className="space-y-2 text-sm text-muted-foreground">
                        <div className="flex items-center gap-2"><MapPin className="w-4 h-4" /><span>{car.city}, {car.pincode}</span></div>
                        <div className="flex items-center gap-2"><Calendar className="w-4 h-4" /><span>{car.year} • {car.kmDriven?.toLocaleString()} km • {car.fuelType}</span></div>
                      </div>

                      {(car.scheduledDate || car.assignedInspector) && (
                         <div className="bg-primary/5 border border-primary/10 rounded-lg p-3 space-y-1 text-xs text-primary/80">
                           <p className="font-bold flex items-center gap-1"><ClipboardCheck className="w-3 h-3" /> Inspection Info</p>
                           {car.scheduledDate && <p className="flex items-center gap-1"><CalendarDays className="w-3 h-3" /> {formatDate(car.scheduledDate)} @ {car.scheduledTime}</p>}
                           {car.assignedInspector && <p className="flex items-center gap-1 mt-1 border-t border-primary/10 pt-1"><User className="w-3 h-3" /> {getInspectorName(car.assignedInspector)}</p>}
                         </div>
                      )}

                      <div className="pt-2 flex flex-col gap-2">
                        {activeTab === "pending_verification" && (
                          <>
                             {(!car.inspectionStatus || car.inspectionStatus === "pending") && (
                                <Button className="w-full gap-2 bg-blue-600 hover:bg-blue-700 text-white" onClick={() => { setSelectedCar(car); setScheduleOpen(true); }}><CalendarDays className="w-4 h-4" /> Schedule Inspection</Button>
                             )}
                             {car.inspectionStatus === "user_accepted" && (
                               <Button className="w-full gap-2 bg-purple-600 hover:bg-purple-700 text-white" onClick={() => { setSelectedCar(car); setAssignOpen(true); }}><UserPlus className="w-4 h-4" /> Assign Inspector</Button>
                             )}
                             {car.inspectionStatus === "completed" && (
                                <Button className="w-full gap-2 bg-green-600 hover:bg-green-700 text-white font-bold" onClick={() => handleViewReport(car._id)}><FileText className="w-4 h-4" /> QC Report & Live</Button>
                             )}
                             <div className="grid grid-cols-2 gap-2 mt-1">
                                <Button onClick={() => { setSelectedCar(car); setDetailsOpen(true); }} variant="outline" size="sm"><Eye className="w-4 h-4 mr-2" /> Details</Button>
                                <Button onClick={() => { setRejectCar(car); setRejectOpen(true); }} variant="outline" size="sm" className="text-destructive hover:bg-red-50 hover:text-destructive border-destructive/20"><XCircle className="w-4 h-4 mr-2" /> Reject</Button>
                             </div>
                          </>
                        )}
                        {activeTab !== "pending_verification" && (
                          <Button onClick={() => { setSelectedCar(car); setDetailsOpen(true); }} className="w-full gap-2" variant="outline"><Eye className="w-4 h-4" /> View Details</Button>
                        )}
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* --- 1. FIXED VIEW DETAILS DIALOG --- */}
      <Dialog open={detailsOpen} onOpenChange={setDetailsOpen}>
        {/* Changed 'glass-card' to 'bg-background' (solid color) to fix transparency/contrast issues */}
        <DialogContent className="bg-background border border-border shadow-xl sm:max-w-4xl max-h-[90vh] overflow-y-auto p-0 gap-0">
          {selectedCar && (
            <>
              {/* Header Image Area */}
              <div className="relative h-64 w-full bg-slate-900">
                {selectedCar.images?.length > 0 ? (
                    <img 
                        src={selectedCar.images[0]} 
                        alt="Car" 
                        className="w-full h-full object-cover opacity-90"
                    />
                ) : (
                    <div className="w-full h-full flex items-center justify-center text-white"><ImageIcon className="w-16 h-16"/></div>
                )}
                <div className="absolute top-4 right-4 flex gap-2">
                    <Badge variant="secondary" className="backdrop-blur-md bg-black/50 text-white border-none">{selectedCar.status}</Badge>
                </div>
                <div className="absolute bottom-0 left-0 w-full bg-gradient-to-t from-black/80 to-transparent p-6">
                    <h2 className="text-2xl md:text-3xl font-bold text-white mb-1">{selectedCar.make} {selectedCar.model} <span className="text-white/80 text-xl font-normal">{selectedCar.variant}</span></h2>
                    <p className="text-white/80 flex items-center gap-2"><MapPin className="w-4 h-4"/> {selectedCar.city}, {selectedCar.pincode}</p>
                </div>
              </div>

              <div className="p-6 space-y-8">
                {/* 1. Price & Basic Stats */}
                <div className="flex flex-wrap items-center justify-between gap-4 border-b pb-6">
                    <div>
                        <p className="text-sm text-muted-foreground uppercase tracking-wide font-semibold">Expected Price</p>
                        <h3 className="text-3xl font-bold text-primary">{formatPrice(selectedCar.expectedPrice)}</h3>
                        {selectedCar.negotiable && <Badge variant="outline" className="mt-1">Negotiable</Badge>}
                    </div>
                    <div className="flex gap-4 md:gap-8">
                         <div className="text-center">
                            <p className="text-xs text-muted-foreground uppercase">Year</p>
                            <p className="font-semibold text-lg">{selectedCar.year}</p>
                         </div>
                         <div className="text-center">
                            <p className="text-xs text-muted-foreground uppercase">Kilometers</p>
                            <p className="font-semibold text-lg">{selectedCar.kmDriven?.toLocaleString()}</p>
                         </div>
                         <div className="text-center">
                            <p className="text-xs text-muted-foreground uppercase">Owners</p>
                            <p className="font-semibold text-lg">{selectedCar.noOfOwners}</p>
                         </div>
                    </div>
                </div>

                {/* 2. Detailed Specifications (Grid) */}
                <div>
                    <h4 className="text-lg font-semibold mb-4 flex items-center gap-2"><Car className="w-5 h-5 text-primary"/> Vehicle Specifications</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        <div className="p-3 bg-muted/30 rounded-lg border">
                            <p className="text-xs text-muted-foreground mb-1">Fuel Type</p>
                            <p className="font-medium flex items-center gap-2"><Fuel className="w-4 h-4 text-muted-foreground"/> {selectedCar.fuelType}</p>
                        </div>
                        <div className="p-3 bg-muted/30 rounded-lg border">
                            <p className="text-xs text-muted-foreground mb-1">Transmission</p>
                            <p className="font-medium flex items-center gap-2"><Gauge className="w-4 h-4 text-muted-foreground"/> {selectedCar.transmission}</p>
                        </div>
                        <div className="p-3 bg-muted/30 rounded-lg border">
                            <p className="text-xs text-muted-foreground mb-1">Color</p>
                            <p className="font-medium flex items-center gap-2"><Palette className="w-4 h-4 text-muted-foreground"/> {selectedCar.color}</p>
                        </div>
                        <div className="p-3 bg-muted/30 rounded-lg border">
                            <p className="text-xs text-muted-foreground mb-1">Registration</p>
                            <p className="font-medium flex items-center gap-2"><Hash className="w-4 h-4 text-muted-foreground"/> {selectedCar.registrationNumber}</p>
                        </div>
                         <div className="p-3 bg-muted/30 rounded-lg border">
                            <p className="text-xs text-muted-foreground mb-1">Reg City</p>
                            <p className="font-medium flex items-center gap-2"><MapPin className="w-4 h-4 text-muted-foreground"/> {selectedCar.registrationCity}</p>
                        </div>
                    </div>
                </div>

                {/* 3. Seller Information */}
                <div>
                    <h4 className="text-lg font-semibold mb-4 flex items-center gap-2"><User className="w-5 h-5 text-primary"/> Seller Details</h4>
                    <div className="bg-muted/20 p-4 rounded-xl border flex flex-col md:flex-row justify-between gap-4">
                        <div className="space-y-1">
                            <p className="text-sm font-bold text-foreground">{selectedCar.sellerName}</p>
                            <p className="text-sm text-muted-foreground flex items-center gap-2"><Phone className="w-3 h-3"/> {selectedCar.sellerMobile}</p>
                            {selectedCar.sellerEmail && <p className="text-sm text-muted-foreground flex items-center gap-2"><Mail className="w-3 h-3"/> {selectedCar.sellerEmail}</p>}
                        </div>
                        <div className="flex gap-2 items-start">
                             <Badge variant="outline">{selectedCar.sellerType}</Badge>
                             <Badge variant="outline">{selectedCar.listingType}</Badge>
                        </div>
                    </div>
                </div>

                {/* 4. Description */}
                {selectedCar.description && (
                     <div>
                        <h4 className="text-lg font-semibold mb-2 flex items-center gap-2"><FileText className="w-5 h-5 text-primary"/> Description</h4>
                        <p className="text-sm text-muted-foreground leading-relaxed bg-muted/10 p-4 rounded-lg border">{selectedCar.description}</p>
                     </div>
                )}
                
                {/* 5. Images Grid (If more than 1) */}
                {selectedCar.images?.length > 1 && (
                    <div>
                        <h4 className="text-lg font-semibold mb-4 flex items-center gap-2"><ImageIcon className="w-5 h-5 text-primary"/> Gallery</h4>
                        <div className="grid grid-cols-3 md:grid-cols-5 gap-2">
                            {selectedCar.images.map((img, i) => (
                                <img key={i} src={img} className="w-full h-24 object-cover rounded-md border cursor-pointer hover:opacity-80 transition-opacity" onClick={() => window.open(img, '_blank')}/>
                            ))}
                        </div>
                    </div>
                )}

              </div>
              
              <div className="p-4 border-t bg-muted/10 flex justify-end gap-2 sticky bottom-0 z-10 backdrop-blur-md">
                 <Button variant="outline" onClick={() => setDetailsOpen(false)}>Close</Button>
                 {activeTab === 'pending_verification' && (
                    <>
                       <Button onClick={() => openEdit(selectedCar)} variant="secondary"><Edit3 className="w-4 h-4 mr-2"/> Edit</Button>
                       <Button onClick={() => { setRejectCar(selectedCar); setRejectOpen(true); }} variant="destructive"><XCircle className="w-4 h-4 mr-2"/> Reject</Button>
                    </>
                 )}
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>

      {/* --- Other Dialogs (Schedule, Assign, Approve, etc.) --- */}
      <Dialog open={scheduleOpen} onOpenChange={setScheduleOpen}>
        <DialogContent className="glass-card border border-border/50 sm:max-w-md">
          <DialogHeader><DialogTitle>Schedule Inspection</DialogTitle></DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2"><Label>Date</Label><Input type="date" onChange={e => setScheduleData({ ...scheduleData, date: e.target.value })} /></div>
            <div className="space-y-2"><Label>Time Slot</Label><Input type="time" onChange={e => setScheduleData({ ...scheduleData, time: e.target.value })} /></div>
          </div>
          <DialogFooter><Button onClick={handleSchedule} className="w-full">Send Schedule</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={assignOpen} onOpenChange={setAssignOpen}>
        <DialogContent className="glass-card border border-border/50">
          <DialogHeader><DialogTitle>Assign Inspector</DialogTitle></DialogHeader>
          <div className="py-4">
            <Label className="mb-2 block">Select Inspector</Label>
            <select className="w-full border p-2 rounded-md bg-background text-foreground" onChange={e => setSelectedInspectorId(e.target.value)} value={selectedInspectorId}>
              <option value="">-- Choose Inspector --</option>
              {inspectors.map(i => <option key={i._id} value={i._id}>{i.fullName} ({i.phone})</option>)}
            </select>
          </div>
          <DialogFooter><Button onClick={handleAssign} disabled={!selectedInspectorId} className="w-full">Assign</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={approveOpen} onOpenChange={setApproveOpen}>
        <DialogContent className="glass-card border border-border/50">
          <DialogHeader><DialogTitle className="flex items-center gap-2 text-green-600"><CheckCircle2 className="w-5 h-5" /> Go Live Approval</DialogTitle></DialogHeader>
          <div className="space-y-5 py-4">
            <div className="space-y-2">
              <Label>Quality Rating (1-10)</Label>
              <Input type="number" min={1} max={10} value={qualityRating} onChange={e => setQualityRating(parseInt(e.target.value))} className="font-bold text-lg" />
            </div>
          </div>
          <DialogFooter><Button onClick={handleApprove} disabled={approving} className="w-full bg-green-600 hover:bg-green-700">{approving ? <Loader2 className="animate-spin w-4 h-4"/> : "Publish Listing 🚀"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="glass-card border border-border/50 max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><ClipboardCheck className="w-5 h-5 text-primary"/> Inspection Report</DialogTitle></DialogHeader>
          {reportLoading ? <div className="py-20 flex justify-center"><Loader2 className="w-8 h-8 animate-spin text-primary"/></div> : reportData ? (
             <div className="space-y-6">
                <div className="grid grid-cols-2 gap-4 bg-muted/30 p-4 rounded-xl border border-border/50">
                   <div><Label className="text-xs uppercase text-muted-foreground">Vehicle</Label><p className="font-bold text-lg">{reportData.make} {reportData.model}</p></div>
                   <div><Label className="text-xs uppercase text-muted-foreground">Inspector</Label><p className="font-bold text-lg">{reportData.inspectionReport?.inspectorName || "Assigned Inspector"}</p></div>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                   {[{ l: "Exterior", s: reportData.inspectionReport?.exteriorScore }, { l: "Interior", s: reportData.inspectionReport?.interiorScore }, { l: "Engine", s: reportData.inspectionReport?.engineMechanicalScore }, { l: "Tyres", s: reportData.inspectionReport?.tyresBrakesScore }].map((item, idx) => (
                      <div key={idx} className="bg-background border border-border rounded-xl p-3 text-center shadow-sm"><p className="text-[10px] uppercase font-bold text-muted-foreground mb-1">{item.l}</p><p className="text-2xl font-black text-primary">{item.s || 0}<span className="text-xs font-normal text-muted-foreground">/10</span></p></div>
                   ))}
                </div>
                {/* ... (Report Content) ... */}
                <DialogFooter className="gap-2"><Button variant="outline" onClick={() => setReportOpen(false)} className="flex-1">Close</Button><Button className="flex-1 bg-green-600 hover:bg-green-700" onClick={() => { setApproveCar(reportData); setApproveOpen(true); }}><Check className="w-4 h-4 mr-2"/> Approve & Live</Button></DialogFooter>
             </div>
          ) : <div className="py-10 text-center">Report Not Found</div>}
        </DialogContent>
      </Dialog>

      <Dialog open={rejectOpen} onOpenChange={setRejectOpen}>
        <DialogContent className="glass-card border border-border/50">
          <DialogHeader><DialogTitle className="text-destructive">Reject Listing</DialogTitle></DialogHeader>
          <Textarea placeholder="Reason..." value={rejectReason} onChange={e => setRejectReason(e.target.value)} className="min-h-[100px]" />
          <DialogFooter><Button variant="outline" onClick={() => setRejectOpen(false)}>Cancel</Button><Button variant="destructive" onClick={handleReject} disabled={rejecting}>Reject</Button></DialogFooter>
        </DialogContent>
      </Dialog>

       <Dialog open={editOpen} onOpenChange={setEditOpen}>
        <DialogContent className="glass-card border border-border/50">
           <DialogHeader><DialogTitle>Edit Listing</DialogTitle></DialogHeader>
           <div className="grid grid-cols-2 gap-4 py-4">
              <div className="space-y-1"><Label>Make</Label><Input value={editForm.make} onChange={e => setEditForm({...editForm, make: e.target.value})}/></div>
              <div className="space-y-1"><Label>Model</Label><Input value={editForm.model} onChange={e => setEditForm({...editForm, model: e.target.value})}/></div>
              <div className="space-y-1"><Label>Price</Label><Input type="number" value={editForm.expectedPrice} onChange={e => setEditForm({...editForm, expectedPrice: parseInt(e.target.value)})}/></div>
           </div>
           <DialogFooter><Button onClick={handleEditSubmit} disabled={editing}>Save</Button></DialogFooter>
        </DialogContent>
       </Dialog>
    </div>
  );
};

export default ListingVerification;