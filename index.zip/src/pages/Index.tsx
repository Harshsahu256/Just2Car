import Login from "@/components/common/Login";

const Index = () => {
  return <Login />;
};

export default Index;
