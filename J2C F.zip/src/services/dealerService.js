// src/services/dealerService.js
import axios from "axios";
import { DEALER_API_ENDPOINTS } from "../authapi/dealerApi";
