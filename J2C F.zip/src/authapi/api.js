// src/authapi/api.js

// export const BASE_URL = "https://seediest-brynlee-nondefensive.ngrok-free.dev/api/v1/auth";

export const BASE_URL = "http://localhost:8002/api/v1/auth";

export const API_ENDPOINTS = {
     LOGIN: `${ BASE_URL}/login`, 

};